# Dungeon Logic Targeted Difficulty Corpus

Seeds: 1, 42, 1337, 12345, 54321, 123456, 654321, 1000003, 305419896, 987654321
Targets: easy, medium, hard, expert

## Target summary

| Target | Seeds complete | Accepted | Pool exact | Pool fallback | Pool exact rate | Shortlist exact | Shortlist fallback | Shortlist exact rate | Backfill seeds | Unrated |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| easy | 10/10 | 500 | 449 | 51 | 89.8% | 150 | 0 | 100.0% | 0 | 0 |
| medium | 10/10 | 500 | 165 | 335 | 33.0% | 144 | 6 | 96.0% | 0 | 0 |
| hard | 10/10 | 500 | 254 | 246 | 50.8% | 150 | 0 | 100.0% | 0 | 0 |
| expert | 10/10 | 500 | 325 | 175 | 65.0% | 150 | 0 | 100.0% | 0 | 0 |

## Archetype contribution

### easy

| Archetype | Accepted | Exact | Fallback |
| --- | ---: | ---: | ---: |
| monster-only | 180 | 170 | 10 |
| chest-one-room | 20 | 1 | 19 |
| chest-two-rooms | 40 | 25 | 15 |
| mixed-one-room | 160 | 160 | 0 |
| mixed-two-rooms | 100 | 93 | 7 |

### medium

| Archetype | Accepted | Exact | Fallback |
| --- | ---: | ---: | ---: |
| monster-only | 100 | 54 | 46 |
| chest-one-room | 60 | 4 | 56 |
| chest-two-rooms | 80 | 38 | 42 |
| mixed-one-room | 100 | 18 | 82 |
| mixed-two-rooms | 160 | 51 | 109 |

### hard

| Archetype | Accepted | Exact | Fallback |
| --- | ---: | ---: | ---: |
| monster-only | 40 | 15 | 25 |
| chest-one-room | 80 | 32 | 48 |
| chest-two-rooms | 200 | 133 | 67 |
| mixed-one-room | 40 | 3 | 37 |
| mixed-two-rooms | 140 | 71 | 69 |

### expert

| Archetype | Accepted | Exact | Fallback |
| --- | ---: | ---: | ---: |
| monster-only | 20 | 1 | 19 |
| chest-one-room | 300 | 300 | 0 |
| chest-two-rooms | 100 | 17 | 83 |
| mixed-one-room | 20 | 1 | 19 |
| mixed-two-rooms | 60 | 6 | 54 |

## Per-seed results

| Target | Seed | Completed | Accepted | Pool exact | Pool fallback | Shortlist slots | Shortlist exact | Shortlist fallback | Backfill | Backfill count | Missing | Unrated |
| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: |
| easy | 1 | yes | 50 | 45 | 5 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| easy | 42 | yes | 50 | 47 | 3 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| easy | 1337 | yes | 50 | 45 | 5 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| easy | 12345 | yes | 50 | 48 | 2 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| easy | 54321 | yes | 50 | 46 | 4 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| easy | 123456 | yes | 50 | 48 | 2 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| easy | 654321 | yes | 50 | 42 | 8 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| easy | 1000003 | yes | 50 | 38 | 12 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| easy | 305419896 | yes | 50 | 45 | 5 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| easy | 987654321 | yes | 50 | 45 | 5 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| medium | 1 | yes | 50 | 17 | 33 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| medium | 42 | yes | 50 | 17 | 33 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| medium | 1337 | yes | 50 | 13 | 37 | 15 | 13 | 2 | no | 0 | 0 | 0 |
| medium | 12345 | yes | 50 | 12 | 38 | 15 | 12 | 3 | no | 0 | 0 | 0 |
| medium | 54321 | yes | 50 | 18 | 32 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| medium | 123456 | yes | 50 | 14 | 36 | 15 | 14 | 1 | no | 0 | 0 | 0 |
| medium | 654321 | yes | 50 | 16 | 34 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| medium | 1000003 | yes | 50 | 21 | 29 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| medium | 305419896 | yes | 50 | 19 | 31 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| medium | 987654321 | yes | 50 | 18 | 32 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| hard | 1 | yes | 50 | 26 | 24 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| hard | 42 | yes | 50 | 25 | 25 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| hard | 1337 | yes | 50 | 27 | 23 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| hard | 12345 | yes | 50 | 20 | 30 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| hard | 54321 | yes | 50 | 34 | 16 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| hard | 123456 | yes | 50 | 26 | 24 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| hard | 654321 | yes | 50 | 21 | 29 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| hard | 1000003 | yes | 50 | 28 | 22 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| hard | 305419896 | yes | 50 | 20 | 30 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| hard | 987654321 | yes | 50 | 27 | 23 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| expert | 1 | yes | 50 | 34 | 16 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| expert | 42 | yes | 50 | 32 | 18 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| expert | 1337 | yes | 50 | 31 | 19 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| expert | 12345 | yes | 50 | 32 | 18 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| expert | 54321 | yes | 50 | 34 | 16 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| expert | 123456 | yes | 50 | 30 | 20 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| expert | 654321 | yes | 50 | 32 | 18 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| expert | 1000003 | yes | 50 | 36 | 14 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| expert | 305419896 | yes | 50 | 32 | 18 | 15 | 15 | 0 | no | 0 | 0 | 0 |
| expert | 987654321 | yes | 50 | 32 | 18 | 15 | 15 | 0 | no | 0 | 0 | 0 |
