# Dungeon Logic Generator v1.2

Master seed: 123456
Difficulty target: easy

Targeted pool: 50 requested
Pool exact: 48
Pool fallback: 2
Global backfill: 0
Shortlist exact: 15/15
Shortlist fallback: 0/15

## Global targeted shortlist

### #1 generated-monster-only-8-2499408487

- archetype: monster-only
- candidate seed: 2499408487
- size: 8x8
- room top-lefts: none
- room spatial profile: none
- row clues: 0, 4, 1, 4, 1, 5, 4, 7
- column clues: 5, 3, 3, 4, 1, 4, 2, 4
- Monsters: (0,1), (0,3), (7,4), (1,5), (2,6), (6,6), (4,7)
- Chests: none
- solutionCount: 1
- difficulty band: easy
- difficulty score: 18
- difficulty reasoning tier: direct
- quality score: 102.75
- diversity score: 0
- selection score: 102.75
- wall density: 0.406
- thick-wall ratio: 0.154
- wall/open boundary: 2.077
- largest wall component: 0.308

```text
........
.#.##.#.
#.......
..##.#.#
#.......
#.##.#.#
##...#.#
####.###
```

### #2 generated-monster-only-6-2398889868

- archetype: monster-only
- candidate seed: 2398889868
- size: 6x6
- room top-lefts: none
- room spatial profile: none
- row clues: 5, 4, 1, 2, 3, 0
- column clues: 4, 2, 2, 2, 3, 2
- Monsters: (2,0), (4,1), (0,3), (0,5)
- Chests: none
- solutionCount: 1
- difficulty band: easy
- difficulty score: 4
- difficulty reasoning tier: direct
- quality score: 102.5
- diversity score: 0.497
- selection score: 105.484
- wall density: 0.417
- thick-wall ratio: 0.267
- wall/open boundary: 1.800
- largest wall component: 0.333

```text
##.###
##.#.#
#.....
..#.#.
#.#.#.
......
```

### #3 generated-monster-only-7-2491075932

- archetype: monster-only
- candidate seed: 2491075932
- size: 7x7
- room top-lefts: none
- room spatial profile: none
- row clues: 5, 5, 3, 2, 2, 3, 4
- column clues: 5, 3, 3, 0, 5, 4, 4
- Monsters: (2,0), (5,1), (0,5), (4,5), (6,5), (1,6)
- Chests: none
- solutionCount: 1
- difficulty band: easy
- difficulty score: 12
- difficulty reasoning tier: direct
- quality score: 101.88
- diversity score: 0.392
- selection score: 104.233
- wall density: 0.490
- thick-wall ratio: 0.167
- wall/open boundary: 1.667
- largest wall component: 0.292

```text
##..###
###.#.#
#...#.#
#.#....
....##.
.##..#.
#...###
```

### #4 generated-monster-only-6-278107510

- archetype: monster-only
- candidate seed: 278107510
- size: 6x6
- room top-lefts: none
- room spatial profile: none
- row clues: 2, 2, 2, 2, 2, 5
- column clues: 1, 2, 3, 1, 4, 4
- Monsters: (5,1), (5,3), (1,5)
- Chests: none
- solutionCount: 1
- difficulty band: easy
- difficulty score: 5
- difficulty reasoning tier: direct
- quality score: 102
- diversity score: 0.146
- selection score: 102.876
- wall density: 0.417
- thick-wall ratio: 0.267
- wall/open boundary: 1.867
- largest wall component: 0.400

```text
....##
.##...
....##
.##...
....##
#.####
```

### #5 generated-monster-only-8-2414387559

- archetype: monster-only
- candidate seed: 2414387559
- size: 8x8
- room top-lefts: none
- room spatial profile: none
- row clues: 3, 6, 0, 6, 3, 5, 3, 6
- column clues: 7, 6, 5, 4, 0, 4, 2, 4
- Monsters: (3,0), (0,2), (2,4), (7,4), (1,6), (6,6), (5,7)
- Chests: none
- solutionCount: 1
- difficulty band: easy
- difficulty score: 16
- difficulty reasoning tier: direct
- quality score: 99.414
- diversity score: 0.32
- selection score: 101.331
- wall density: 0.500
- thick-wall ratio: 0.375
- wall/open boundary: 1.563
- largest wall component: 0.469

```text
###.....
####.##.
........
####.#.#
##...#..
####...#
#....#.#
####..##
```

### #1 generated-chest-one-room-7-3193369624

- archetype: chest-one-room
- candidate seed: 3193369624
- size: 7x7
- room top-lefts: (4,1)
- room spatial profile: edge
- row clues: 4, 2, 2, 2, 4, 2, 4
- column clues: 0, 5, 0, 6, 3, 2, 4
- Monsters: none
- Chests: (6,2)
- solutionCount: 1
- difficulty band: easy
- difficulty score: 10
- difficulty reasoning tier: direct
- quality score: 100
- diversity score: 0.388
- selection score: 102.326
- wall density: 0.408
- thick-wall ratio: 0.000
- wall/open boundary: 1.700
- largest wall component: 0.450

```text
...####
.#.#...
.#.#...
.#.#...
.#.##.#
.#....#
...####
```

### #1 generated-chest-two-rooms-7-2951199908

- archetype: chest-two-rooms
- candidate seed: 2951199908
- size: 7x7
- room top-lefts: (0,4), (4,4)
- room spatial profile: corner + corner
- row clues: 3, 5, 2, 5, 1, 1, 1
- column clues: 4, 0, 2, 5, 1, 2, 4
- Monsters: none
- Chests: (0,6), (4,6)
- solutionCount: 1
- difficulty band: easy
- difficulty score: 12
- difficulty reasoning tier: direct
- quality score: 100
- diversity score: 0.224
- selection score: 101.342
- wall density: 0.367
- thick-wall ratio: 0.222
- wall/open boundary: 1.667
- largest wall component: 0.333

```text
#....##
#.##.##
#.....#
#.###.#
...#...
...#...
...#...
```

### #1 generated-mixed-one-room-7-1494863578

- archetype: mixed-one-room
- candidate seed: 1494863578
- size: 7x7
- room top-lefts: (3,2)
- room spatial profile: interior
- row clues: 4, 5, 3, 1, 3, 4, 1
- column clues: 5, 1, 3, 2, 2, 3, 5
- Monsters: (4,0), (0,3), (0,5), (6,5)
- Chests: (5,3)
- solutionCount: 1
- difficulty band: easy
- difficulty score: 11
- difficulty reasoning tier: direct
- quality score: 102.5
- diversity score: 0.241
- selection score: 103.946
- wall density: 0.429
- thick-wall ratio: 0.190
- wall/open boundary: 1.762
- largest wall component: 0.429

```text
##...##
#..####
#.#...#
......#
#.#...#
..####.
#......
```

### #2 generated-mixed-one-room-8-1936134028

- archetype: mixed-one-room
- candidate seed: 1936134028
- size: 8x8
- room top-lefts: (0,0)
- room spatial profile: corner
- row clues: 5, 4, 3, 3, 4, 2, 4, 1
- column clues: 3, 0, 3, 3, 3, 5, 2, 7
- Monsters: (4,1), (6,2), (0,4), (0,6), (7,7)
- Chests: (0,0)
- solutionCount: 1
- difficulty band: easy
- difficulty score: 15
- difficulty reasoning tier: direct
- quality score: 100.929
- diversity score: 0.304
- selection score: 102.752
- wall density: 0.406
- thick-wall ratio: 0.231
- wall/open boundary: 1.846
- largest wall component: 0.615

```text
...#####
...#.###
...#.#.#
#.#....#
..#.##.#
#......#
..#.##.#
#.......
```

### #3 generated-mixed-one-room-6-3627574953

- archetype: mixed-one-room
- candidate seed: 3627574953
- size: 6x6
- room top-lefts: (0,1)
- room spatial profile: edge
- row clues: 3, 2, 0, 2, 4, 5
- column clues: 3, 3, 3, 3, 1, 3
- Monsters: (3,0), (3,4), (4,5)
- Chests: (0,2)
- solutionCount: 1
- difficulty band: easy
- difficulty score: 7
- difficulty reasoning tier: direct
- quality score: 100.95
- diversity score: 0.218
- selection score: 102.258
- wall density: 0.444
- thick-wall ratio: 0.375
- wall/open boundary: 1.500
- largest wall component: 0.438

```text
###...
...##.
......
...#.#
###..#
####.#
```

### #4 generated-mixed-one-room-8-4234123378

- archetype: mixed-one-room
- candidate seed: 4234123378
- size: 8x8
- room top-lefts: (0,5)
- room spatial profile: corner
- row clues: 7, 6, 3, 1, 4, 3, 0, 3
- column clues: 4, 3, 4, 4, 5, 0, 5, 2
- Monsters: (5,0), (6,1), (1,2), (7,2), (0,3), (5,7), (7,7)
- Chests: (0,6)
- solutionCount: 1
- difficulty band: easy
- difficulty score: 18
- difficulty reasoning tier: direct
- quality score: 100.848
- diversity score: 0.181
- selection score: 101.934
- wall density: 0.422
- thick-wall ratio: 0.370
- wall/open boundary: 1.778
- largest wall component: 0.444

```text
#####.##
#####..#
#.#...#.
....#...
###...#.
...##.#.
........
...##.#.
```

### #5 generated-mixed-one-room-8-3372573810

- archetype: mixed-one-room
- candidate seed: 3372573810
- size: 8x8
- room top-lefts: (0,2)
- room spatial profile: edge
- row clues: 7, 6, 1, 3, 4, 3, 4, 3
- column clues: 4, 2, 4, 5, 1, 5, 4, 6
- Monsters: (4,0), (7,1), (6,3), (6,5), (0,6), (1,7), (6,7)
- Chests: (2,3)
- solutionCount: 1
- difficulty band: easy
- difficulty score: 18
- difficulty reasoning tier: direct
- quality score: 100.063
- diversity score: 0.097
- selection score: 100.648
- wall density: 0.484
- thick-wall ratio: 0.387
- wall/open boundary: 1.548
- largest wall component: 0.355

```text
####.###
####.##.
...#....
...#.#.#
...#.###
#.#....#
....####
#.#....#
```

### #1 generated-mixed-two-rooms-8-3155662824

- archetype: mixed-two-rooms
- candidate seed: 3155662824
- size: 8x8
- room top-lefts: (0,1), (0,5)
- room spatial profile: corner + edge
- row clues: 7, 3, 3, 1, 5, 1, 2, 4
- column clues: 2, 2, 2, 5, 0, 5, 5, 5
- Monsters: (4,0), (5,1), (3,4), (6,6), (4,7)
- Chests: (1,1), (1,7)
- solutionCount: 1
- difficulty band: easy
- difficulty score: 16
- difficulty reasoning tier: direct
- quality score: 100
- diversity score: 0.16
- selection score: 100.958
- wall density: 0.406
- thick-wall ratio: 0.231
- wall/open boundary: 1.769
- largest wall component: 0.308

```text
####.###
...#..##
.....###
...#....
###..##.
...#....
.....#.#
...#.###
```

### #2 generated-mixed-two-rooms-7-4032331667

- archetype: mixed-two-rooms
- candidate seed: 4032331667
- size: 7x7
- room top-lefts: (4,0), (4,4)
- room spatial profile: corner + corner
- row clues: 4, 2, 3, 6, 1, 2, 2
- column clues: 6, 5, 1, 5, 1, 1, 1
- Monsters: (0,4), (1,6)
- Chests: (5,2), (5,4)
- solutionCount: 1
- difficulty band: easy
- difficulty score: 10
- difficulty reasoning tier: direct
- quality score: 97.9
- diversity score: 0.312
- selection score: 99.77
- wall density: 0.408
- thick-wall ratio: 0.400
- wall/open boundary: 1.450
- largest wall component: 0.500

```text
####...
##.....
##.#...
##.####
...#...
##.....
#..#...
```

### #3 generated-mixed-two-rooms-7-3103505586

- archetype: mixed-two-rooms
- candidate seed: 3103505586
- size: 7x7
- room top-lefts: (0,0), (0,4)
- room spatial profile: corner + corner
- row clues: 4, 2, 3, 4, 3, 1, 4
- column clues: 1, 1, 1, 5, 2, 5, 6
- Monsters: (6,3), (5,5)
- Chests: (0,2), (0,5)
- solutionCount: 1
- difficulty band: easy
- difficulty score: 10
- difficulty reasoning tier: direct
- quality score: 97.817
- diversity score: 0.224
- selection score: 99.159
- wall density: 0.429
- thick-wall ratio: 0.286
- wall/open boundary: 1.381
- largest wall component: 0.381

```text
...####
.....##
...#.##
####...
...#.##
......#
...####
```
