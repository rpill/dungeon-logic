# Treasure Room Structural Consensus What-If

Seeds: 42, 987654321

This diagnostic keeps production Human Solver unchanged. It replays the existing stuck state, then runs the current loop `direct -> ordinary contradiction -> TreasureRoomVariant`; only when that loop would otherwise stop does it apply structural consensus across all direct-surviving Treasure Room `footprint + sole entrance` variants and repeat.

## Seed 42

- completed: true
- accepted: 50
- unrated: 1

### generated-chest-one-room-8-1796543048

- candidate seed: 1796543048
- archetype: chest-one-room
- size: 8x8
- initial status: stuck
- initial unknown: 63
- final status: stuck
- final unknown: 58
- structural consensus steps: 1
- structural consensus assignments: 5
- new direct steps after original stuck point: 0
- new ordinary contradiction steps after original stuck point: 0
- new TreasureRoomVariant steps after original stuck point: 0

#### Structural consensus moves

##### Move 1

- chest: (2,3)
- surviving variants: 4
- surviving footprints: 2
- assignments: (2,2)=WALL (2,4)=OPEN (2,5)=OPEN (3,5)=OPEN (2,6)=WALL

## Seed 987654321

- completed: true
- accepted: 50
- unrated: 1

### generated-chest-one-room-8-1549878292

- candidate seed: 1549878292
- archetype: chest-one-room
- size: 8x8
- initial status: stuck
- initial unknown: 62
- final status: solved-with-contradiction
- final unknown: 0
- structural consensus steps: 1
- structural consensus assignments: 3
- new direct steps after original stuck point: 28
- new ordinary contradiction steps after original stuck point: 17
- new TreasureRoomVariant steps after original stuck point: 0

#### Structural consensus moves

##### Move 1

- chest: (2,4)
- surviving variants: 5
- surviving footprints: 2
- assignments: (2,1)=WALL (2,2)=OPEN (2,5)=WALL

