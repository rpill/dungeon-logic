# Treasure Room Structural Consensus Diagnostic

Seeds: 42, 987654321

This diagnostic tests every currently viable `3x3 footprint + sole entrance` structural variant with direct deductions only. It reports consensus from the structural variants themselves; it does not commit arbitrary downstream direct-closure consensus.

## Seed 42

- completed: true
- accepted: 50
- unrated: 1

### generated-chest-one-room-8-1796543048

- candidate seed: 1796543048
- archetype: chest-one-room
- size: 8x8
- human status: stuck
- unknown at stop: 63

#### Chest (2,3)

- viable footprints before structural probing: 9
- structural room+entrance variants tested: 99
- surviving variants after direct closure: 4
- surviving footprints: 2

| Footprint top-left | Variants tested | Survivors | Surviving entrances | Direct steps in survivors |
| --- | ---: | ---: | --- | --- |
| (0,1) | 9 | 0 | none | - |
| (1,1) | 12 | 0 | none | - |
| (2,1) | 12 | 0 | none | - |
| (0,2) | 9 | 0 | none | - |
| (1,2) | 12 | 0 | none | - |
| (2,2) | 12 | 0 | none | - |
| (0,3) | 9 | 1 | (3,5) | 3 |
| (1,3) | 12 | 0 | none | - |
| (2,3) | 12 | 3 | (1,3) (1,4) (5,4) | 6..28 |

##### Structural consensus across all survivors

- common room interior: (2,3) (2,4) (2,5)
- common closed boundary: (2,2) (2,6)
- common entrance: none
- all structural consensus assignments: (2,2)=WALL (2,3)=OPEN (2,4)=OPEN (2,5)=OPEN (3,5)=OPEN (2,6)=WALL
- actionable unresolved assignments: (2,2)=WALL (2,4)=OPEN (2,5)=OPEN (3,5)=OPEN (2,6)=WALL
- actionable count: 5

##### After applying structural consensus (diagnostic probe only)

- assignments applied: 5
- direct closure valid: true
- new direct steps: 0
- unknown remaining after consensus + direct closure: 58

#### Canonical solution

```text
###...##
#...#...
..#####.
.#...#..
.#.....#
.#...#.#
..####.#
#......#
```

## Seed 987654321

- completed: true
- accepted: 50
- unrated: 1

### generated-chest-one-room-8-1549878292

- candidate seed: 1549878292
- archetype: chest-one-room
- size: 8x8
- human status: stuck
- unknown at stop: 62

#### Chest (2,4)

- viable footprints before structural probing: 9
- structural room+entrance variants tested: 99
- surviving variants after direct closure: 5
- surviving footprints: 2

| Footprint top-left | Variants tested | Survivors | Surviving entrances | Direct steps in survivors |
| --- | ---: | ---: | --- | --- |
| (0,2) | 9 | 3 | (3,2) (3,3) (3,4) | 1 |
| (1,2) | 12 | 0 | none | - |
| (2,2) | 12 | 2 | (1,3) (5,3) | 5..31 |
| (0,3) | 9 | 0 | none | - |
| (1,3) | 12 | 0 | none | - |
| (2,3) | 12 | 0 | none | - |
| (0,4) | 9 | 0 | none | - |
| (1,4) | 12 | 0 | none | - |
| (2,4) | 12 | 0 | none | - |

##### Structural consensus across all survivors

- common room interior: (2,2) (2,3) (2,4)
- common closed boundary: (2,1) (2,5)
- common entrance: none
- all structural consensus assignments: (2,1)=WALL (2,2)=OPEN (2,3)=OPEN (2,4)=OPEN (2,5)=WALL
- actionable unresolved assignments: (2,1)=WALL (2,2)=OPEN (2,5)=WALL
- actionable count: 3

##### After applying structural consensus (diagnostic probe only)

- assignments applied: 3
- direct closure valid: true
- new direct steps: 0
- unknown remaining after consensus + direct closure: 59

#### Canonical solution

```text
#......#
..####..
.#...##.
.#......
.#...##.
..####..
#....#.#
####...#
```

