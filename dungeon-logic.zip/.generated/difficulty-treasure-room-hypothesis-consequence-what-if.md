# Treasure Room Hypothesis Consequence What-If

Seed: 42

This diagnostic keeps production Human Solver unchanged. It runs the current loop `direct -> ordinary contradiction -> TreasureRoomVariant`, then structural Treasure Room consensus. If that still stalls, it tests every surviving `footprint + sole entrance` hypothesis with direct closure and commits only cell states shared by every surviving branch.

- completed: true
- accepted: 50
- unrated: 1

## generated-chest-one-room-8-1796543048

- candidate seed: 1796543048
- archetype: chest-one-room
- size: 8x8
- initial status: stuck
- initial unknown: 63
- final status: solved-with-contradiction
- final unknown: 0
- structural consensus steps: 1
- structural consensus assignments: 5
- hypothesis consequence steps: 1
- hypothesis consequence assignments: 5
- new direct steps after original stuck point: 25
- new ordinary contradiction steps after original stuck point: 14
- new TreasureRoomVariant steps after original stuck point: 0

### Structural consensus moves

#### Structural move 1

- chest: (2,3)
- surviving variants: 4
- surviving footprints: 2
- assignments: (2,2)=WALL (2,4)=OPEN (2,5)=OPEN (3,5)=OPEN (2,6)=WALL

### Hypothesis consequence moves

#### Consequence move 1

- chest: (2,3)
- surviving variants: 4
- surviving footprints: 2
- direct steps across survivors: 3..28
- assignments: (3,0)=OPEN (3,1)=OPEN (0,3)=OPEN (0,4)=OPEN (3,7)=OPEN

