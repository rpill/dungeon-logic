# Dungeon Logic Difficulty Corpus

Seeds: 1, 42, 1337, 12345, 54321, 123456, 654321, 1000003, 305419896, 987654321
Seed count: 10
Completed seeds: 10
Accepted candidates: 502
Accepted per archetype target: 10
Shortlist slots per archetype: 3

## Accepted difficulty distribution

| Band | Count | Share |
| --- | ---: | ---: |
| easy | 238 | 47.4% |
| medium | 69 | 13.7% |
| hard | 108 | 21.5% |
| expert | 87 | 17.3% |
| unrated | 0 | 0.0% |

## Archetype coverage

### monster-only

Accepted: 100

| Band | Total | Min/seed | Max/seed | Seeds any | Seeds full | Classification |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| easy | 54 | 4 | 8 | 10/10 | 10/10 | stable-full |
| medium | 25 | 1 | 4 | 10/10 | 6/10 | partial |
| hard | 19 | 0 | 5 | 9/10 | 3/10 | partial |
| expert | 2 | 0 | 1 | 2/10 | 0/10 | partial |

### chest-one-room

Accepted: 100

| Band | Total | Min/seed | Max/seed | Seeds any | Seeds full | Classification |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| easy | 5 | 0 | 2 | 3/10 | 0/10 | partial |
| medium | 3 | 0 | 1 | 3/10 | 0/10 | partial |
| hard | 20 | 0 | 4 | 9/10 | 3/10 | partial |
| expert | 72 | 4 | 9 | 10/10 | 10/10 | stable-full |

### chest-two-rooms

Accepted: 102

| Band | Total | Min/seed | Max/seed | Seeds any | Seeds full | Classification |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| easy | 34 | 2 | 7 | 10/10 | 6/10 | partial |
| medium | 19 | 0 | 5 | 8/10 | 3/10 | partial |
| hard | 41 | 3 | 6 | 10/10 | 10/10 | stable-full |
| expert | 8 | 0 | 2 | 6/10 | 0/10 | partial |

### mixed-one-room

Accepted: 100

| Band | Total | Min/seed | Max/seed | Seeds any | Seeds full | Classification |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| easy | 88 | 8 | 10 | 10/10 | 10/10 | stable-full |
| medium | 7 | 0 | 2 | 5/10 | 0/10 | partial |
| hard | 4 | 0 | 2 | 3/10 | 0/10 | partial |
| expert | 1 | 0 | 1 | 1/10 | 0/10 | partial |

### mixed-two-rooms

Accepted: 100

| Band | Total | Min/seed | Max/seed | Seeds any | Seeds full | Classification |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| easy | 57 | 3 | 8 | 10/10 | 10/10 | stable-full |
| medium | 15 | 0 | 3 | 9/10 | 1/10 | partial |
| hard | 24 | 0 | 4 | 9/10 | 5/10 | partial |
| expert | 4 | 0 | 1 | 4/10 | 0/10 | partial |

### Coverage classification

- stable-full: monster-only/easy, chest-one-room/expert, chest-two-rooms/hard, mixed-one-room/easy, mixed-two-rooms/easy
- partial: monster-only/medium, monster-only/hard, monster-only/expert, chest-one-room/easy, chest-one-room/medium, chest-one-room/hard, chest-two-rooms/easy, chest-two-rooms/medium, chest-two-rooms/expert, mixed-one-room/medium, mixed-one-room/hard, mixed-one-room/expert, mixed-two-rooms/medium, mixed-two-rooms/hard, mixed-two-rooms/expert
- none: none

## Target shortlist performance

| Target | Slots | Exact | Fallback | Exact rate |
| --- | ---: | ---: | ---: | ---: |
| easy | 150 | 113 | 37 | 75.3% |
| medium | 150 | 63 | 87 | 42.0% |
| hard | 150 | 85 | 65 | 56.7% |
| expert | 150 | 45 | 105 | 30.0% |

### Target: easy

| Archetype | Slots | Exact | Fallback |
| --- | ---: | ---: | ---: |
| monster-only | 30 | 30 | 0 |
| chest-one-room | 30 | 5 | 25 |
| chest-two-rooms | 30 | 20 | 10 |
| mixed-one-room | 30 | 30 | 0 |
| mixed-two-rooms | 30 | 28 | 2 |

### Target: medium

| Archetype | Slots | Exact | Fallback |
| --- | ---: | ---: | ---: |
| monster-only | 30 | 24 | 6 |
| chest-one-room | 30 | 3 | 27 |
| chest-two-rooms | 30 | 14 | 16 |
| mixed-one-room | 30 | 7 | 23 |
| mixed-two-rooms | 30 | 15 | 15 |

### Target: hard

| Archetype | Slots | Exact | Fallback |
| --- | ---: | ---: | ---: |
| monster-only | 30 | 17 | 13 |
| chest-one-room | 30 | 19 | 11 |
| chest-two-rooms | 30 | 24 | 6 |
| mixed-one-room | 30 | 4 | 26 |
| mixed-two-rooms | 30 | 21 | 9 |

### Target: expert

| Archetype | Slots | Exact | Fallback |
| --- | ---: | ---: | ---: |
| monster-only | 30 | 2 | 28 |
| chest-one-room | 30 | 30 | 0 |
| chest-two-rooms | 30 | 8 | 22 |
| mixed-one-room | 30 | 1 | 29 |
| mixed-two-rooms | 30 | 4 | 26 |

## Per-seed summary

### Seed 1

- completed: true
- accepted: 50
- bands: easy=22 medium=9 hard=10 expert=9 unrated=0
- target easy: exact=11/15 fallback=4
- target medium: exact=7/15 fallback=8
- target hard: exact=8/15 fallback=7
- target expert: exact=4/15 fallback=11

### Seed 42

- completed: true
- accepted: 50
- bands: easy=22 medium=5 hard=14 expert=9 unrated=0
- target easy: exact=10/15 fallback=5
- target medium: exact=5/15 fallback=10
- target hard: exact=11/15 fallback=4
- target expert: exact=4/15 fallback=11

### Seed 1337

- completed: true
- accepted: 50
- bands: easy=28 medium=5 hard=10 expert=7 unrated=0
- target easy: exact=13/15 fallback=2
- target medium: exact=5/15 fallback=10
- target hard: exact=7/15 fallback=8
- target expert: exact=4/15 fallback=11

### Seed 12345

- completed: true
- accepted: 50
- bands: easy=28 medium=5 hard=10 expert=7 unrated=0
- target easy: exact=13/15 fallback=2
- target medium: exact=5/15 fallback=10
- target hard: exact=9/15 fallback=6
- target expert: exact=3/15 fallback=12

### Seed 54321

- completed: true
- accepted: 50
- bands: easy=21 medium=9 hard=9 expert=11 unrated=0
- target easy: exact=11/15 fallback=4
- target medium: exact=9/15 fallback=6
- target hard: exact=7/15 fallback=8
- target expert: exact=7/15 fallback=8

### Seed 123456

- completed: true
- accepted: 50
- bands: easy=30 medium=7 hard=9 expert=4 unrated=0
- target easy: exact=12/15 fallback=3
- target medium: exact=6/15 fallback=9
- target hard: exact=8/15 fallback=7
- target expert: exact=3/15 fallback=12

### Seed 654321

- completed: true
- accepted: 50
- bands: easy=22 medium=9 hard=10 expert=9 unrated=0
- target easy: exact=11/15 fallback=4
- target medium: exact=7/15 fallback=8
- target hard: exact=7/15 fallback=8
- target expert: exact=4/15 fallback=11

### Seed 1000003

- completed: true
- accepted: 51
- bands: easy=18 medium=6 hard=16 expert=11 unrated=0
- target easy: exact=10/15 fallback=5
- target medium: exact=6/15 fallback=9
- target hard: exact=12/15 fallback=3
- target expert: exact=7/15 fallback=8

### Seed 305419896

- completed: true
- accepted: 51
- bands: easy=26 medium=7 hard=8 expert=10 unrated=0
- target easy: exact=11/15 fallback=4
- target medium: exact=6/15 fallback=9
- target hard: exact=7/15 fallback=8
- target expert: exact=5/15 fallback=10

### Seed 987654321

- completed: true
- accepted: 50
- bands: easy=21 medium=7 hard=12 expert=10 unrated=0
- target easy: exact=11/15 fallback=4
- target medium: exact=7/15 fallback=8
- target hard: exact=9/15 fallback=6
- target expert: exact=4/15 fallback=11
