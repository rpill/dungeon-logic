# Difficulty Unrated Diagnostic

Seeds: 42, 987654321

## Seed 42

- completed: true
- accepted: 50
- unrated: 1

### generated-chest-one-room-8-1796543048

- candidate seed: 1796543048
- archetype: chest-one-room
- size: 8x8
- difficulty reasons: Human Solver is stuck with 63 mutable cells unresolved.
- human status: stuck
- direct steps: 0
- contradiction steps: 0
- assignments: 0
- unknown remaining: 63
- potential connectivity valid at stop: true

#### Rule counts

- line-complete: 0
- line-fill: 0
- door: 0
- treasure-room-interior: 0
- treasure-room-entrance: 0
- treasure-room-variant: 0
- monster-dead-end: 0
- hallway-not-dead-end: 0
- open-2x2: 0
- connectivity: 0
- contradiction: 0

#### Committed board at stop

```text
????????
????????
????????
??C?????
????????
????????
????????
????????
```

Legend: `#` WALL, `.` committed OPEN, `?` unresolved mutable, `M` Monster, `C` Chest, `D` Directional Door, `B` Blocker.

#### Line status at stop

| Line | Target walls | Walls placed | Unresolved |
| --- | ---: | ---: | ---: |
| row 0 | 5 | 0 | 8 |
| row 1 | 2 | 0 | 8 |
| row 2 | 5 | 0 | 8 |
| row 3 | 2 | 0 | 7 |
| row 4 | 2 | 0 | 8 |
| row 5 | 3 | 0 | 8 |
| row 6 | 5 | 0 | 8 |
| row 7 | 2 | 0 | 8 |
| column 0 | 3 | 0 | 8 |
| column 1 | 4 | 0 | 8 |
| column 2 | 3 | 0 | 7 |
| column 3 | 2 | 0 | 8 |
| column 4 | 3 | 0 | 8 |
| column 5 | 4 | 0 | 8 |
| column 6 | 2 | 0 | 8 |
| column 7 | 5 | 0 | 8 |

#### Treasure Room state at stop

- chest (2,3): 9 viable footprints; top-lefts (0,1) (1,1) (2,1) (0,2) (1,2) (2,2) (0,3) (1,3) (2,3)

#### Human steps

- no committed steps

#### Canonical solution

```text
###...##
#...#...
..#####.
.#...#..
.#.....#
.#...#.#
..####.#
#......#
```

- row clues: 5, 2, 5, 2, 2, 3, 5, 2
- column clues: 3, 4, 3, 2, 3, 4, 2, 5
- monsters: none
- chests: (2,3)
- blockers: none
- doors: none

## Seed 987654321

- completed: true
- accepted: 50
- unrated: 1

### generated-chest-one-room-8-1549878292

- candidate seed: 1549878292
- archetype: chest-one-room
- size: 8x8
- difficulty reasons: Human Solver is stuck with 62 mutable cells unresolved.
- human status: stuck
- direct steps: 0
- contradiction steps: 1
- assignments: 1
- unknown remaining: 62
- potential connectivity valid at stop: true

#### Rule counts

- line-complete: 0
- line-fill: 0
- door: 0
- treasure-room-interior: 0
- treasure-room-entrance: 0
- treasure-room-variant: 0
- monster-dead-end: 0
- hallway-not-dead-end: 0
- open-2x2: 0
- connectivity: 0
- contradiction: 1

#### Committed board at stop

```text
????????
????????
????????
??.?????
??C?????
????????
????????
????????
```

Legend: `#` WALL, `.` committed OPEN, `?` unresolved mutable, `M` Monster, `C` Chest, `D` Directional Door, `B` Blocker.

#### Line status at stop

| Line | Target walls | Walls placed | Unresolved |
| --- | ---: | ---: | ---: |
| row 0 | 2 | 0 | 8 |
| row 1 | 4 | 0 | 8 |
| row 2 | 3 | 0 | 8 |
| row 3 | 1 | 0 | 7 |
| row 4 | 3 | 0 | 7 |
| row 5 | 4 | 0 | 8 |
| row 6 | 3 | 0 | 8 |
| row 7 | 5 | 0 | 8 |
| column 0 | 3 | 0 | 8 |
| column 1 | 4 | 0 | 8 |
| column 2 | 3 | 0 | 6 |
| column 3 | 3 | 0 | 8 |
| column 4 | 2 | 0 | 8 |
| column 5 | 5 | 0 | 8 |
| column 6 | 2 | 0 | 8 |
| column 7 | 3 | 0 | 8 |

#### Treasure Room state at stop

- chest (2,4): 9 viable footprints; top-lefts (0,2) (1,2) (2,2) (0,3) (1,3) (2,3) (0,4) (1,4) (2,4)

#### Human steps

- 1. [contradiction/contradiction] Assuming (2,3) is WALL leads to a direct contradiction, so it must be OPEN.

#### Canonical solution

```text
#......#
..####..
.#...##.
.#......
.#...##.
..####..
#....#.#
####...#
```

- row clues: 2, 4, 3, 1, 3, 4, 3, 5
- column clues: 3, 4, 3, 3, 2, 5, 2, 3
- monsters: none
- chests: (2,4)
- blockers: none
- doors: none

