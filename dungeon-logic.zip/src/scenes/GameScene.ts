import Phaser from 'phaser';

import { BoardView } from '../board/BoardView';
import { CAMPAIGN_SERVICE_REGISTRY_KEY, CampaignService } from '../campaign/CampaignService';
import type {
  CampaignCompletionMetadata,
  CampaignCompletionResult,
  GameSceneData,
} from '../campaign/types';
import {
  DAILY_SERVICE_REGISTRY_KEY,
  DailyService,
  getRecentDailyHistory,
  type DailyCompletionResult,
} from '../daily/DailyService';
import { encodeDailyLeaderboardScore, getDailyLeaderboardName } from '../daily/DailyLeaderboard';
import { chooseHint, requestHint, type PuzzleHint } from '../gameplay/HintService';
import { RANKED_DAILY_HINT_UNLOCK_MS } from '../gameplay/HintEconomy';
import { MonetizationService } from '../monetization/MonetizationService';
import { PuzzleInteractionSession } from '../gameplay/PuzzleInteractionSession';
import { ActiveTimer, formatActiveTime } from '../gameplay/ActiveTimer';
import { PuzzleSessionService } from '../gameplay/PuzzleSessionService';
import { validatePuzzle } from '../puzzle/LevelValidator';
import { PLATFORM_SERVICES_REGISTRY_KEY } from '../platform/PlatformRegistry';
import type { LeaderboardPlayerView, PlatformServices } from '../platform/services';
import { PuzzleState } from '../puzzle/PuzzleState';
import {
  createOnboardingFlow,
  isOnboardingStepSatisfied,
  type OnboardingStep,
} from '../onboarding/OnboardingFlow';
import { HELP_SCENE_KEY } from '../help/HelpNavigation';
import { getUiCopy } from '../i18n/UiCopy';
import {
  PLAYER_PROFILE_SERVICE_REGISTRY_KEY,
  PlayerProfileService,
} from '../profile/PlayerProfileService';
import {
  completeDailyGameLaunch,
  completeGameLaunch,
  createCampaignGameSceneData,
  createNextCampaignGameSceneData,
  createTutorialGameSceneData,
} from '../runtime/GameLaunch';
import { ARCHIVE_SCENE_KEY, HOME_SCENE_KEY, SETTINGS_SCENE_KEY, STATS_SCENE_KEY } from '../runtime/MetaSelectors';
import {
  TUTORIAL_SERVICE_REGISTRY_KEY,
  TutorialService,
  type TutorialCompletionResult,
} from '../tutorial/TutorialService';
import { createCompletedReviewPuzzle, resolveCampaignPlayState } from '../runtime/CampaignPlayState';
import { calculateGameBoardLayout } from './GameBoardLayout';
import { LEADERBOARD_SCENE_KEY } from './LeaderboardScene';
import { DAILY_SCENE_KEY } from './DailyScene';
import { calculatePuzzleChromeLayout } from '../runtime/ResponsiveLayout';
import { PlatformGameplayActivity } from '../runtime/PlatformGameplayActivity';
import {
  calculatePuzzleToolbarLayout,
  createPuzzleToolbarState,
  shouldConfirmReset,
  shouldShowTouchToolButtons,
  type PuzzleToolbarButtonId,
  type PuzzleToolbarLayout,
} from '../runtime/PuzzleUiState';

export class GameScene extends Phaser.Scene {
  private createVersion = 0;
  private launchData: GameSceneData | null = null;

  constructor() {
    super('GameScene');
  }

  init(data: GameSceneData): void {
    this.launchData = data;
  }

  create(): void {
    const launchData = this.launchData;
    if (launchData === null) {
      throw new Error('GameScene requires resolved GameSceneData from campaign, Daily, or dev routing.');
    }

    const createVersion = this.createVersion + 1;
    this.createVersion = createVersion;
    this.createGame(launchData, createVersion);
  }

  private createGame(launchData: GameSceneData, createVersion: number): void {
    const readSafeArea = (name: '--safe-area-inset-top' | '--safe-area-inset-bottom'): number => {
      if (typeof document === 'undefined' || typeof getComputedStyle === 'undefined') {
        return 0;
      }
      const raw = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
      const value = Number.parseFloat(raw);
      return Number.isFinite(value) ? Math.max(0, value) : 0;
    };

    const readActiveClockMs = (): number => {
      if (typeof performance !== 'undefined') {
        const value = performance.now();
        if (Number.isFinite(value) && value >= 0) return value;
      }
      return Date.now();
    };

    const calculateSafeBoardLayout = (extraBottomReserve = 0) => {
      const safeTop = readSafeArea('--safe-area-inset-top');
      const safeBottom = readSafeArea('--safe-area-inset-bottom');
      const safeHeight = Math.max(
        1,
        this.scale.height - safeTop - safeBottom - Math.max(0, extraBottomReserve),
      );
      const layout = calculateGameBoardLayout(
        this.scale.width,
        safeHeight,
        launchData.level.width,
        launchData.level.height,
      );
      return {
        ...layout,
        originY: layout.originY + safeTop,
      };
    };

    const safeTop = readSafeArea('--safe-area-inset-top');
    const chrome = calculatePuzzleChromeLayout(this.scale.width, this.scale.height);
    const profileService = launchData.context.mode === 'dev'
      ? null
      : this.getPlayerProfileService();
    let language = this.getPlayerProfileService().getProfile().settings.language;
    let copy = getUiCopy(language);
    const campaignContext = launchData.context.mode === 'campaign'
      ? launchData.context
      : null;
    const campaignService = campaignContext === null ? null : this.getCampaignService();
    const tutorialContext = launchData.context.mode === 'tutorial'
      ? launchData.context
      : null;
    const dailyContext = launchData.context.mode === 'daily'
      ? launchData.context
      : null;
    const rankedDaily = dailyContext?.ranked === true;
    const tutorialService = tutorialContext === null ? null : this.getTutorialService();
    const tutorialEntry = tutorialContext === null
      ? null
      : tutorialService?.getLevels().find((entry) => entry.id === tutorialContext.tutorialLevelId) ?? null;
    const tutorialLevelTotal = tutorialService?.getLevels().length ?? 0;
    const campaignEntry = campaignContext === null
      ? null
      : campaignService?.getLevels().find((entry) => entry.id === campaignContext.campaignLevelId) ?? null;
    const completedCampaignSlot = campaignEntry?.slot ?? null;
    const campaignLevelTotal = campaignService?.getLevels().length ?? 0;
    const campaignPlayState = campaignContext !== null && profileService !== null
      ? resolveCampaignPlayState(launchData.level, profileService.getProfile().campaign)
      : null;
    const completedReview = campaignPlayState?.mode === 'completed-review';

    if (
      completedReview
      && profileService?.getProfile().campaign.activePuzzle?.puzzleId === launchData.level.id
    ) {
      profileService.update((profile) => ({
        ...profile,
        campaign: {
          ...profile.campaign,
          activePuzzle: null,
        },
      }));
    }

    const getTitleLabel = (): string => {
      if (campaignEntry !== null) {
        return copy.game.levelTitle(campaignEntry.slot, campaignLevelTotal);
      }
      if (tutorialEntry !== null) {
        return copy.game.tutorialTitle(tutorialEntry.slot, tutorialLevelTotal);
      }
      if (launchData.context.mode === 'daily') return copy.game.dailyTitle;
      return 'Dungeon Logic';
    };

    const titleText = this.add.text(
      this.scale.width / 2,
      chrome.titleY + safeTop,
      getTitleLabel(),
      {
        fontFamily: 'monospace',
        fontSize: `${chrome.titleFontSize}px`,
        color: '#f0e6d2',
        fontStyle: 'bold',
      },
    ).setOrigin(0.5);

    const timerText = this.add.text(
      this.scale.width / 2,
      chrome.titleY + safeTop + (this.scale.width < 700 ? 28 : 34),
      '00:00',
      {
        fontFamily: 'monospace',
        fontSize: `${Math.max(12, chrome.statusFontSize)}px`,
        color: '#89929d',
        fontStyle: 'bold',
      },
    ).setOrigin(0.5);

    const backText = this.add.text(chrome.actionInset, chrome.titleY + safeTop, copy.game.back, {
      fontFamily: 'monospace',
      fontSize: `${chrome.actionFontSize}px`,
      color: '#89929d',
      fontStyle: 'bold',
    })
      .setOrigin(0, 0.5)
      .setInteractive({ useHandCursor: true });

    const helpText = this.add.text(
      this.scale.width - chrome.actionInset,
      chrome.titleY + safeTop,
      this.scale.width < 700 ? 'ⓘ' : copy.game.rules,
      {
        fontFamily: 'monospace',
        fontSize: `${chrome.actionFontSize}px`,
        color: '#89929d',
        fontStyle: 'bold',
      },
    ).setOrigin(1, 0.5).setInteractive({ useHandCursor: true });

    const settingsText = this.add.text(
      this.scale.width - chrome.actionInset - (this.scale.width < 700 ? 38 : 118),
      chrome.titleY + safeTop,
      '⚙',
      {
        fontFamily: 'monospace',
        fontSize: `${Math.max(16, chrome.actionFontSize + 2)}px`,
        color: '#89929d',
        fontStyle: 'bold',
      },
    ).setOrigin(1, 0.5).setInteractive({ useHandCursor: true });

    const platformServices = this.registry.get(PLATFORM_SERVICES_REGISTRY_KEY) as PlatformServices | null | undefined;
    const monetizationService = profileService !== null && platformServices != null
      ? MonetizationService.create(profileService, platformServices.ads)
      : null;
    const rewardedHintAvailable = platformServices?.kind === 'yandex'
      && monetizationService !== null;
    const submitRankedDailyResult = async (
      result: DailyCompletionResult,
    ): Promise<LeaderboardPlayerView | null> => {
      if (!result.ranked || platformServices == null) return null;
      const leaderboardName = getDailyLeaderboardName(result.dailyId);
      const packedScore = encodeDailyLeaderboardScore(result.dateKey, result.result.bestTimeMs);
      const submission = await platformServices.leaderboards.submitScore(
        leaderboardName,
        packedScore,
        JSON.stringify({
          dailyId: result.dailyId,
          dateKey: result.dateKey,
          timeMs: Math.floor(result.result.bestTimeMs),
        }),
      );
      if (submission !== 'submitted') return null;
      return platformServices.leaderboards.getPlayerEntry(leaderboardName);
    };
    const puzzleSession = profileService === null || completedReview
      ? null
      : campaignContext !== null
        ? PuzzleSessionService.createCampaign(
          launchData.level,
          profileService,
          campaignPlayState?.mode === 'active' ? campaignPlayState.savedPuzzle : undefined,
        )
        : tutorialContext !== null
          ? PuzzleSessionService.createTutorial(
            launchData.level,
            profileService,
            profileService.getProfile().tutorial.activePuzzle ?? undefined,
          )
          : rankedDaily
            ? PuzzleSessionService.createDaily(
              launchData.level,
              profileService,
              profileService.getProfile().daily.activePuzzle ?? undefined,
            )
            : null;
    const puzzle = completedReview
      ? createCompletedReviewPuzzle(launchData.level)
      : puzzleSession?.getPuzzle() ?? new PuzzleState(launchData.level);
    puzzleSession?.saveNow();
    const interaction = new PuzzleInteractionSession(puzzle);
    let boardLayout = calculateSafeBoardLayout();

    let board: BoardView | null = null;
    let solved = completedReview;
    let onboardingOpen = false;
    let onboardingBlocksInteraction = false;
    let onboardingBlocksTimer = false;
    let resetDialogOpen = false;
    let resetDialog: Phaser.GameObjects.Container | null = null;
    let hintConfirmOpen = false;
    let hintConfirmMode: 'free' | 'rewarded' | null = null;
    let rewardedHintRequestPending = false;
    let hintConfirmContainer: Phaser.GameObjects.Container | null = null;
    let currentHint: PuzzleHint | null = null;
    let completionMode = false;
    let completionTransitionPending = false;
    const completionButtons: Array<{
      rectangle: Phaser.GameObjects.Rectangle;
      label: Phaser.GameObjects.Text;
    }> = [];
    const initialTimerMs = completedReview
      ? campaignPlayState?.displayTimeMs ?? 0
      : rankedDaily
        ? dailyContext?.elapsedMsAtLaunch ?? 0
        : puzzleSession?.getActivePlayMs() ?? 0;
    const activeTimer = new ActiveTimer(initialTimerMs);
    const rankedDailyDisplayAnchorMs = rankedDaily ? Date.now() : 0;
    const rankedDailyInitialElapsedMs = rankedDaily ? initialTimerMs : 0;
    const getDisplayedElapsedMs = (nowMs = readActiveClockMs()): number => {
      if (!rankedDaily) return activeTimer.getElapsedMs(nowMs);
      return rankedDailyInitialElapsedMs + Math.max(0, Date.now() - rankedDailyDisplayAnchorMs);
    };
    const formatHintCountdown = (ms: number): string => {
      const totalSeconds = Math.max(0, Math.ceil(ms / 1000));
      const minutes = Math.floor(totalSeconds / 60);
      const seconds = totalSeconds % 60;
      return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    };
    const rankedDailyHintRemainingMs = (): number => (
      rankedDaily ? Math.max(0, RANKED_DAILY_HINT_UNLOCK_MS - getDisplayedElapsedMs()) : 0
    );
    const rankedDailyHintUnlocked = (): boolean => rankedDailyHintRemainingMs() <= 0;
    let syncedActivePlayMs = initialTimerMs;
    let transientHintsUsed = 0;
    let sceneOverlayPaused = false;
    const platformGameplayActivity = platformServices == null
      ? null
      : new PlatformGameplayActivity(
        platformServices.gameplay,
        platformServices.lifecycle.isPaused(),
      );

    const updateTimerText = (nowMs = readActiveClockMs()): void => {
      timerText.setText(formatActiveTime(getDisplayedElapsedMs(nowMs)));
    };

    const syncTimerIntoSession = (nowMs = readActiveClockMs()): void => {
      const elapsedMs = activeTimer.getElapsedMs(nowMs);
      if (elapsedMs > syncedActivePlayMs) {
        const activeDeltaMs = elapsedMs - syncedActivePlayMs;
        puzzleSession?.addActiveTime(activeDeltaMs);
        profileService?.addActivePlayTime(activeDeltaMs);
        syncedActivePlayMs = elapsedMs;
      }
      updateTimerText(nowMs);
    };

    const internalTimerMayRun = (): boolean => {
      if (solved || onboardingBlocksTimer || resetDialogOpen || hintConfirmOpen || sceneOverlayPaused) return false;
      return typeof document === 'undefined' || !document.hidden;
    };

    const timerMayRun = (): boolean => (
      internalTimerMayRun() && platformGameplayActivity?.isPlatformPaused() !== true
    );

    const pauseActiveTimer = (syncGameplayMarkup = true): void => {
      const nowMs = readActiveClockMs();
      activeTimer.pause(nowMs);
      syncTimerIntoSession(nowMs);
      if (syncGameplayMarkup) platformGameplayActivity?.stopInternal();
    };

    const resumeActiveTimer = (syncGameplayMarkup = true): void => {
      if (!internalTimerMayRun()) return;
      if (syncGameplayMarkup) platformGameplayActivity?.startInternal();
      if (!timerMayRun()) return;
      const nowMs = readActiveClockMs();
      activeTimer.resume(nowMs);
      updateTimerText(nowMs);
    };

    const savePuzzleSession = (): void => {
      syncTimerIntoSession();
      puzzleSession?.saveNow();
    };

    const flushProfileState = async (): Promise<void> => {
      if (puzzleSession !== null) {
        await puzzleSession.flush();
        return;
      }
      if (profileService !== null) {
        await profileService.flush();
      }
    };

    const showTouchToolButtons = shouldShowTouchToolButtons(
      typeof window !== 'undefined' && typeof window.matchMedia === 'function'
        ? window.matchMedia('(any-pointer: coarse)').matches
        : false,
      typeof navigator !== 'undefined' ? navigator.maxTouchPoints : 0,
    );

    const toolbarVisuals = new Map<
      PuzzleToolbarButtonId,
      { rectangle: Phaser.GameObjects.Rectangle; label: Phaser.GameObjects.Text }
    >();
    let toolbarLayout: PuzzleToolbarLayout = calculatePuzzleToolbarLayout(
      this.scale.width,
      this.scale.height,
      readSafeArea('--safe-area-inset-bottom'),
      showTouchToolButtons,
    );

    const statusText = this.add.text(
      this.scale.width / 2,
      Math.min(...toolbarLayout.buttons.map((button) => button.y - button.height / 2)) - 18,
      showTouchToolButtons ? '' : copy.game.mouseControls,
      {
        fontFamily: 'monospace',
        fontSize: `${chrome.statusFontSize}px`,
        color: '#89929d',
        fontStyle: 'bold',
      },
    ).setOrigin(0.5);

    const onboardingSteps = launchData.context.mode === 'tutorial'
      && launchData.contextualOnboarding
      ? createOnboardingFlow(launchData.context.tutorialLevelId, language)
      : [];
    const hasSavedTutorialProgress = tutorialContext !== null && onboardingSteps.some((step) => (
      step.cells.some(({ x, y }) => puzzle.getCellState(x, y) !== 'unknown')
    ));
    const firstUnsatisfiedTutorialStep = hasSavedTutorialProgress
      ? onboardingSteps.findIndex((step) => (
        !isOnboardingStepSatisfied(step, (x, y) => puzzle.getCellState(x, y))
      ))
      : -1;
    let onboardingIndex = onboardingSteps.length === 0
      ? -1
      : firstUnsatisfiedTutorialStep >= 0
        ? firstUnsatisfiedTutorialStep
        : hasSavedTutorialProgress
          ? onboardingSteps.length - 1
          : 0;
    onboardingOpen = onboardingIndex >= 0;

    const onboardingGuides = Array.from({ length: 12 }, () => (
      this.add.rectangle(0, 0, 1, 1, 0xd0b978, 0.18)
        .setVisible(false)
        .setDepth(40)
    ));
    const onboardingPanel = this.add.rectangle(0, 0, 1, 1, 0x171b20, 0.96)
      .setVisible(false)
      .setDepth(50);
    const onboardingText = this.add.text(0, 0, '', {
      fontFamily: 'monospace',
      fontSize: '14px',
      color: '#f0e6d2',
      align: 'center',
      wordWrap: { width: 420 },
    })
      .setOrigin(0.5)
      .setVisible(false)
      .setDepth(51);
    const onboardingActionText = this.add.text(0, 0, '', {
      fontFamily: 'monospace',
      fontSize: '11px',
      color: '#d0b978',
      fontStyle: 'bold',
    })
      .setOrigin(0.5)
      .setVisible(false)
      .setDepth(51);
    const currentOnboardingStep = (): OnboardingStep | null => (
      onboardingIndex >= 0 ? onboardingSteps[onboardingIndex] ?? null : null
    );

    const hideOnboardingGuides = (): void => {
      for (const guide of onboardingGuides) guide.setVisible(false);
    };

    const relayoutOnboarding = (): void => {
      const step = currentOnboardingStep();
      hideOnboardingGuides();
      if (!onboardingOpen || step === null) {
        onboardingPanel.setVisible(false);
        onboardingText.setVisible(false);
        onboardingActionText.setVisible(false);
        return;
      }

      const toolbarTop = Math.min(
        ...toolbarLayout.buttons.map((button) => button.y - button.height / 2),
      );
      const panelWidth = Math.min(this.scale.width - 24, this.scale.width < 700 ? 390 : 620);
      const panelX = this.scale.width / 2;

      const wallStep = step.expectedState === 'wall';
      const action = showTouchToolButtons
        ? wallStep
          ? copy.game.onboardingTouchWall
          : copy.game.onboardingTouchFloor
        : wallStep
          ? copy.game.onboardingMouseWall
          : copy.game.onboardingMouseFloor;

      onboardingText
        .setWordWrapWidth(Math.max(120, panelWidth - 28), true)
        .setFontSize(this.scale.width < 700 ? 13 : 14)
        .setText(step.message);
      onboardingActionText.setText(action);

      const actionReserve = action.length > 0 ? 28 : 0;
      const panelHeight = Math.max(
        this.scale.width < 700 ? 92 : 76,
        onboardingText.height + 24 + actionReserve,
      );
      const panelY = toolbarTop - panelHeight / 2 - 10;

      onboardingPanel
        .setPosition(panelX, panelY)
        .setDisplaySize(panelWidth, panelHeight)
        .setVisible(true);
      onboardingText
        .setPosition(panelX, panelY - actionReserve / 2)
        .setVisible(true);
      onboardingActionText
        .setPosition(panelX, panelY + panelHeight / 2 - 14)
        .setVisible(action.length > 0);


      const guideSize = Math.max(1, boardLayout.cellSize - 6);
      let guideIndex = 0;
      const placeGuide = (x: number, y: number): void => {
        const guide = onboardingGuides[guideIndex++];
        if (guide === undefined) return;
        guide
          .setPosition(x, y)
          .setDisplaySize(guideSize, guideSize)
          .setVisible(true);
      };

      if (step.guideClue !== undefined) {
        if (step.guideClue.axis === 'row') {
          placeGuide(
            boardLayout.originX - boardLayout.cellSize / 2,
            boardLayout.originY + step.guideClue.index * boardLayout.cellSize + boardLayout.cellSize / 2,
          );
        } else {
          placeGuide(
            boardLayout.originX + step.guideClue.index * boardLayout.cellSize + boardLayout.cellSize / 2,
            boardLayout.originY - boardLayout.cellSize / 2,
          );
        }
      }

      for (const { x, y } of step.cells) {
        placeGuide(
          boardLayout.originX + x * boardLayout.cellSize + boardLayout.cellSize / 2,
          boardLayout.originY + y * boardLayout.cellSize + boardLayout.cellSize / 2,
        );
      }

    };

    const controlsLocked = (): boolean => (
      solved
      || onboardingBlocksInteraction
      || resetDialogOpen
      || hintConfirmOpen
      || platformGameplayActivity?.isPlatformPaused() === true
    );

    const onboardingAllowsTool = (tool: 'wall' | 'floor'): boolean => {
      const step = currentOnboardingStep();
      if (!onboardingOpen || step === null) return true;
      return step.expectedState === tool;
    };

    const syncToolbar = (): void => {
      const hintStatus = profileService?.getHintRechargeStatus(Date.now());
      const rankedHintOpen = !rankedDaily || rankedDailyHintUnlocked();
      const state = createPuzzleToolbarState(
        interaction.getActiveTool(),
        interaction.canUndo(),
        showTouchToolButtons,
        rankedHintOpen ? hintStatus?.freeRemaining ?? 0 : 0,
        rankedHintOpen && rewardedHintAvailable,
        language,
        rankedDaily && !rankedHintOpen
          ? {
            label: copy.game.hintLocked(formatHintCountdown(rankedDailyHintRemainingMs())),
            disabled: true,
          }
          : undefined,
      );
      const step = currentOnboardingStep();

      for (const buttonState of state.buttons) {
        const visual = toolbarVisuals.get(buttonState.id);
        if (visual === undefined) continue;

        const isToolButton = buttonState.id === 'wall' || buttonState.id === 'floor';
        const toolAllowed = isToolButton
          ? onboardingAllowsTool(buttonState.id)
          : !onboardingBlocksInteraction;
        const resetAllowedInReview = completedReview && buttonState.id === 'reset';
        const disabled = (solved && !resetAllowedInReview)
          || resetDialogOpen
          || !toolAllowed
          || buttonState.disabled
          || (buttonState.id === 'reset' && !completedReview && interaction.getEditCount() === 0)
          || (buttonState.id === 'hint' && currentHint !== null);
        const guided = onboardingOpen
          && step !== null
          && buttonState.id === step.expectedState;
        const fill = disabled
          ? 0x191d22
          : guided
            ? 0x8a5155
            : buttonState.active
              ? 0x714245
              : 0x2a3038;
        const textColor = disabled
          ? '#5f666f'
          : guided
            ? '#fff0e8'
            : buttonState.active
              ? '#f5ded7'
              : '#d8d1c4';

        visual.rectangle.setFillStyle(fill, 1);
        visual.label.setText(buttonState.label).setColor(textColor);
      }
    };

    const setToolbarVisible = (visible: boolean): void => {
      for (const visual of toolbarVisuals.values()) {
        visual.rectangle.setVisible(visible);
        visual.label.setVisible(visible);
      }
    };

    const defaultStatusCopy = (): string => (
      showTouchToolButtons ? '' : copy.game.mouseControls
    );

    const refreshStatusText = (): void => {
      if (completedReview) {
        const result = campaignContext === null || profileService === null
          ? undefined
          : profileService.getProfile().campaign.levelResults[campaignContext.campaignLevelId];
        const hintCopy = result === undefined || result.minHintsUsed === 0
          ? copy.game.withoutHints
          : copy.game.hintsCount(result.minHintsUsed);
        statusText
          .setWordWrapWidth(Math.max(120, this.scale.width - 24), true)
          .setAlign('center')
          .setText(result === undefined
            ? copy.common.solved
            : copy.game.solvedCampaign(formatActiveTime(result.bestTimeMs), hintCopy, '', ''))
          .setColor('#d8d1c4')
          .setVisible(true);
        return;
      }
      if (completionMode || hintConfirmOpen || onboardingOpen) return;
      if (currentHint !== null) {
        statusText
          .setText(currentHint.state === 'wall'
            ? copy.game.hintWall
            : copy.game.hintFloor)
          .setColor('#d0b978')
          .setVisible(true);
        return;
      }
      const hintStatus = profileService?.getHintRechargeStatus(Date.now());
      if (!rankedDaily && hintStatus?.freeRemaining === 0 && hintStatus.nextRefillInMs !== null) {
        statusText
          .setText(copy.game.hintRechargeStatus(formatHintCountdown(hintStatus.nextRefillInMs)))
          .setColor('#89929d')
          .setVisible(true);
        return;
      }
      statusText
        .setText(defaultStatusCopy())
        .setColor('#89929d')
        .setVisible(true);
    };

    const closeHintConfirm = (): void => {
      if (rewardedHintRequestPending) return;
      hintConfirmContainer?.destroy(true);
      hintConfirmContainer = null;
      hintConfirmOpen = false;
      hintConfirmMode = null;
      if (!solved && !onboardingOpen && !resetDialogOpen) {
        board?.setInputEnabled(platformGameplayActivity?.isPlatformPaused() !== true);
      }
      setToolbarVisible(!completionMode);
      refreshStatusText();
      resumeActiveTimer();
      syncToolbar();
    };

    const applyDeliveredHint = (hint: PuzzleHint): void => {
      if (profileService === null) return;

      if (puzzleSession !== null) {
        puzzleSession.recordHint();
      } else if (launchData.context.mode === 'daily') {
        transientHintsUsed += 1;
      }
      currentHint = hint;
      board?.setHintCellTarget(hint);
      if (showTouchToolButtons) {
        board?.setActiveTool(hint.state === 'wall' ? 'wall' : 'floor');
      }
      savePuzzleSession();
    };

    const deliverConfirmedHint = async (): Promise<void> => {
      if (profileService === null || rewardedHintRequestPending) {
        closeHintConfirm();
        return;
      }

      const rewardedMode = hintConfirmMode === 'rewarded';
      if (rewardedMode && (monetizationService === null || !rewardedHintAvailable)) {
        closeHintConfirm();
        return;
      }

      rewardedHintRequestPending = true;
      if (rewardedMode) {
        statusText
          .setText(copy.game.loadingAd)
          .setColor('#d0b978')
          .setVisible(true);
      }

      await requestHint({
        puzzle,
        consumeFreeHint: () => profileService.consumeFreeHint(Date.now()),
        requestRewarded: monetizationService === null
          ? null
          : () => monetizationService.requestRewardedHint(),
        recordRewardedHintUsed: () => profileService.recordRewardedHintUsed(),
        deliverHint: applyDeliveredHint,
      });

      rewardedHintRequestPending = false;
      if (createVersion !== this.createVersion || !this.scene.isActive()) return;
      closeHintConfirm();
    };

    const renderHintConfirm = (): void => {
      hintConfirmContainer?.destroy(true);
      hintConfirmContainer = null;
      if (!hintConfirmOpen) return;

      const safeBottom = readSafeArea('--safe-area-inset-bottom');
      const width = Math.min(360, this.scale.width - 24);
      const gap = 10;
      const buttonWidth = Math.floor((width - gap) / 2);
      const buttonHeight = 46;
      const y = this.scale.height - safeBottom - 12 - buttonHeight / 2;
      const container = this.add.container(this.scale.width / 2, y).setDepth(70);
      hintConfirmContainer = container;

      const cancelX = -buttonWidth / 2 - gap / 2;
      const showX = buttonWidth / 2 + gap / 2;
      const cancel = this.add.rectangle(cancelX, 0, buttonWidth, buttonHeight, 0x2a3038, 1)
        .setInteractive({ useHandCursor: true });
      const confirm = this.add.rectangle(showX, 0, buttonWidth, buttonHeight, 0x714245, 1)
        .setInteractive({ useHandCursor: true });
      const cancelLabel = this.add.text(cancelX, 0, copy.common.cancel, {
        fontFamily: 'monospace',
        fontSize: '14px',
        color: '#d8d1c4',
        fontStyle: 'bold',
      }).setOrigin(0.5);
      const confirmLabel = this.add.text(
        showX,
        0,
        hintConfirmMode === 'rewarded' ? copy.game.ad : copy.game.show,
        {
        fontFamily: 'monospace',
        fontSize: '14px',
        color: '#f5ded7',
        fontStyle: 'bold',
        },
      ).setOrigin(0.5);

      cancel.on('pointerup', closeHintConfirm);
      confirm.on('pointerup', () => {
        void deliverConfirmedHint();
      });
      container.add([cancel, confirm, cancelLabel, confirmLabel]);
    };

    const showHintConfirm = (): void => {
      if (rankedDaily && !rankedDailyHintUnlocked()) {
        syncToolbar();
        return;
      }
      if (currentHint !== null) {
        refreshStatusText();
        return;
      }
      if (controlsLocked() || profileService === null || chooseHint(puzzle) === null) return;
      const remaining = profileService.getFreeHintsRemaining(Date.now());
      const mode: 'free' | 'rewarded' = remaining > 0 ? 'free' : 'rewarded';
      if (mode === 'rewarded' && !rewardedHintAvailable) return;

      hintConfirmOpen = true;
      hintConfirmMode = mode;
      board?.setInputEnabled(false);
      pauseActiveTimer();
      setToolbarVisible(false);
      const basePrompt = mode === 'rewarded'
        ? copy.game.rewardedPrompt
        : copy.game.freeHintPrompt(remaining);
      statusText
        .setText(rankedDaily ? `${copy.game.dailyHintOutsideRating}
${basePrompt}` : basePrompt)
        .setColor('#d0b978')
        .setVisible(true);
      renderHintConfirm();
      syncToolbar();
    };

    const clearCompletionButtons = (): void => {
      for (const visual of completionButtons.splice(0)) {
        visual.rectangle.destroy();
        visual.label.destroy();
      }
    };

    let completionActions: Array<{ readonly label: string; readonly action: () => void }> = [];

    const positionCompletionStatusText = (): void => {
      const safeBottom = readSafeArea('--safe-area-inset-bottom');
      const buttonHeight = 48;
      const buttonTop = this.scale.height - safeBottom - 12 - buttonHeight;
      statusText
        .setOrigin(0.5, 1)
        .setPosition(this.scale.width / 2, buttonTop - 18)
        .setWordWrapWidth(Math.max(120, this.scale.width - 32), true)
        .setAlign('center');
    };

    const renderCompletionButtons = (): void => {
      clearCompletionButtons();
      if (!completionMode || completionActions.length === 0) return;
      positionCompletionStatusText();

      const safeBottom = readSafeArea('--safe-area-inset-bottom');
      const count = completionActions.length;
      const gap = count >= 3 ? 8 : 10;
      const maxWidth = Math.min(this.scale.width - 24, count >= 3 ? 560 : 350);
      const buttonHeight = 48;
      const buttonWidth = count === 1
        ? Math.min(190, maxWidth)
        : Math.floor((maxWidth - gap * (count - 1)) / count);
      const totalWidth = buttonWidth * count + gap * (count - 1);
      const startX = (this.scale.width - totalWidth) / 2;
      const y = this.scale.height - safeBottom - 12 - buttonHeight / 2;

      completionActions.forEach((definition, index) => {
        const x = startX + index * (buttonWidth + gap) + buttonWidth / 2;
        const rectangle = this.add.rectangle(x, y, buttonWidth, buttonHeight, 0x2a3038, 1)
          .setInteractive({ useHandCursor: true })
          .setDepth(60);
        const label = this.add.text(x, y, definition.label, {
          fontFamily: 'monospace',
          fontSize: count >= 3
            ? (this.scale.width < 700 ? '12px' : '14px')
            : (this.scale.width < 700 ? '14px' : '16px'),
          color: '#f0d28a',
          fontStyle: 'bold',
        }).setOrigin(0.5).setDepth(61);
        rectangle.on('pointerup', definition.action);
        completionButtons.push({ rectangle, label });
      });
    };

    const launchUnlockedDaily = (): void => {
      if (completionTransitionPending) return;
      completionTransitionPending = true;
      pauseActiveTimer();
      this.scene.start(DAILY_SCENE_KEY);
    };

    const showCompletionState = (
      result: CampaignCompletionResult,
      metadata: CampaignCompletionMetadata,
      newBestTime: boolean,
    ): void => {
      completionMode = true;
      currentHint = null;
      board?.setHintCellTarget(null);
      if (this.scale.height < 520) {
        boardLayout = calculateSafeBoardLayout(40);
        board?.relayout(boardLayout.originX, boardLayout.originY, boardLayout.cellSize);
      }
      setToolbarVisible(false);
      const hintCopy = metadata.minHintsUsed === 0
        ? copy.game.withoutHints
        : copy.game.hintsCount(metadata.minHintsUsed);
      const recordCopy = newBestTime ? copy.game.newRecord : '';
      const unlockCopy = result.unlockedManuscript === null
        ? ''
        : copy.game.manuscriptUnlocked(
          result.unlockedManuscript.roman,
          copy.manuscripts[result.unlockedManuscript.id],
        );
      const solvedCopy = copy.game.solvedCampaign(
        formatActiveTime(metadata.bestTimeMs),
        hintCopy,
        recordCopy,
        unlockCopy,
      );
      const featureUnlockCopy = result.unlockedFeatures.length > 0
        ? `

${copy.game.featuresUnlocked}`
        : '';
      statusText
        .setWordWrapWidth(Math.max(120, this.scale.width - 24), true)
        .setAlign('center')
        .setText(`${solvedCopy}${featureUnlockCopy}`)
        .setColor('#d8d1c4')
        .setVisible(true);

      const continueCampaign = (): void => {
        if (result.recommendedNextLevel === null || completionTransitionPending) return;
        completionTransitionPending = true;
        pauseActiveTimer();
        const service = this.getCampaignService();
        const transition = async (): Promise<void> => {
          if (monetizationService !== null && completedCampaignSlot !== null) {
            await monetizationService.maybeShowCampaignInterstitial(completedCampaignSlot);
          }
          if (createVersion !== this.createVersion) return;
          await this.startNextLevel(result.recommendedNextLevel!, service, createVersion);
        };
        void transition().finally(() => {
          if (createVersion === this.createVersion) completionTransitionPending = false;
        });
      };

      if (result.unlockedFeatures.length > 0) {
        completionActions = [
          {
            label: copy.game.dailyTitle,
            action: launchUnlockedDaily,
          },
          {
            label: copy.common.statistics,
            action: () => this.scene.start(STATS_SCENE_KEY),
          },
          result.recommendedNextLevel === null
            ? {
              label: copy.game.home,
              action: () => this.scene.start(HOME_SCENE_KEY),
            }
            : {
              label: copy.game.next,
              action: continueCampaign,
            },
        ];
      } else {
        completionActions = [
          {
            label: copy.game.archive,
            action: () => this.scene.start(ARCHIVE_SCENE_KEY),
          },
        ];
        if (result.recommendedNextLevel !== null) {
          completionActions.push({
            label: copy.game.next,
            action: continueCampaign,
          });
        }
      }
      renderCompletionButtons();
    };

    const showTutorialCompletionState = (
      result: TutorialCompletionResult,
    ): void => {
      completionMode = true;
      onboardingIndex = -1;
      onboardingOpen = false;
      onboardingBlocksInteraction = false;
      onboardingBlocksTimer = false;
      currentHint = null;
      board?.setHintCellTarget(null);
      board?.setInputCellTargets(null);
      relayoutOnboarding();
      if (this.scale.height < 520) {
        boardLayout = calculateSafeBoardLayout(40);
        board?.relayout(boardLayout.originX, boardLayout.originY, boardLayout.cellSize);
      }
      setToolbarVisible(false);

      statusText
        .setWordWrapWidth(Math.max(120, this.scale.width - 24), true)
        .setAlign('center')
        .setText(
          result.tutorialCompleted && result.recommendedNextLevel === null
            ? copy.game.tutorialComplete
            : `✓ ${copy.common.solved}`,
        )
        .setColor('#d8d1c4')
        .setVisible(true);

      completionActions = [
        {
          label: copy.game.home,
          action: () => this.scene.start(HOME_SCENE_KEY),
        },
      ];

      if (result.recommendedNextLevel !== null) {
        const nextLevel = result.recommendedNextLevel;
        const service = this.getTutorialService();
        completionActions.push({
          label: copy.game.next,
          action: () => {
            if (completionTransitionPending) return;
            completionTransitionPending = true;
            void service.startLevel(nextLevel.id)
              .then((started) => {
                if (createVersion !== this.createVersion) return;
                this.scene.restart(createTutorialGameSceneData(started));
              })
              .catch((error) => {
                console.error(`[Dungeon Logic] Could not start ${nextLevel.id}.`, error);
                completionTransitionPending = false;
              });
          },
        });
      } else if (result.tutorialCompleted) {
        completionActions.push({
          label: copy.game.startChapterOne,
          action: () => {
            if (completionTransitionPending) return;
            const service = this.getCampaignService();
            const firstLevel = service.getLevels()[0];
            if (firstLevel === undefined) return;
            completionTransitionPending = true;
            void service.startLevel(firstLevel.id)
              .then((started) => {
                if (createVersion !== this.createVersion) return;
                this.scene.restart(createCampaignGameSceneData(started, service.getProgress()));
              })
              .catch((error) => {
                console.error('[Dungeon Logic] Could not start Campaign after Tutorial.', error);
                completionTransitionPending = false;
              });
          },
        });
      }
      renderCompletionButtons();
    };

    const showDailyCompletionState = (
      result: DailyCompletionResult,
      leaderboardEntry: LeaderboardPlayerView | null,
    ): void => {
      completionMode = true;
      currentHint = null;
      board?.setHintCellTarget(null);
      if (this.scale.height < 520) {
        boardLayout = calculateSafeBoardLayout(40);
        board?.relayout(boardLayout.originX, boardLayout.originY, boardLayout.cellSize);
      }
      setToolbarVisible(false);

      const recent = getRecentDailyHistory(
        result.dateKey,
        this.getDailyService().getHistory().solvedDates,
        7,
      );
      const recentCopy = recent
        .map((day) => day.solved ? (day.isToday ? '◆' : '●') : '·')
        .join(' ');
      const rankingCopy = leaderboardEntry === null
        ? copy.game.dailyResultFixed
        : `${copy.game.dailyResultFixed} · ${copy.game.dailyPlace(leaderboardEntry.place)}`;

      statusText
        .setWordWrapWidth(Math.max(120, this.scale.width - 24), true)
        .setAlign('center')
        .setText(
          `${rankingCopy}
${copy.game.solvedDaily(formatActiveTime(result.result.bestTimeMs), copy.game.withoutHints, '')}`
          + `
${copy.game.streakRecent(result.currentStreak, recentCopy)}`,
        )
        .setColor('#d8d1c4')
        .setVisible(true);

      completionActions = [
        {
          label: copy.game.home,
          action: () => this.scene.start(HOME_SCENE_KEY),
        },
        {
          label: copy.common.leaderboard,
          action: () => this.scene.start(LEADERBOARD_SCENE_KEY, {
            dailyId: result.dailyId,
            dateKey: result.dateKey,
          }),
        },
      ];
      renderCompletionButtons();
    };

    const showDailyArchiveCompletionState = (
      result: DailyCompletionResult,
    ): void => {
      completionMode = true;
      currentHint = null;
      board?.setHintCellTarget(null);
      setToolbarVisible(false);
      statusText
        .setWordWrapWidth(Math.max(120, this.scale.width - 24), true)
        .setAlign('center')
        .setText(
          `${copy.game.dailyArchiveComplete}
${copy.game.dailyArchiveFirstResult(formatActiveTime(result.result.bestTimeMs))}
${copy.game.dailyArchiveOutsideRating}`,
        )
        .setColor('#d8d1c4')
        .setVisible(true);
      completionActions = [
        {
          label: copy.game.dailyTitle,
          action: () => this.scene.start(DAILY_SCENE_KEY),
        },
        {
          label: copy.game.home,
          action: () => this.scene.start(HOME_SCENE_KEY),
        },
      ];
      renderCompletionButtons();
    };

    const showDailyAssistedCompletionState = (
      result: DailyCompletionResult,
    ): void => {
      completionMode = true;
      currentHint = null;
      board?.setHintCellTarget(null);
      setToolbarVisible(false);
      const recent = getRecentDailyHistory(
        result.dateKey,
        this.getDailyService().getHistory().solvedDates,
        7,
      );
      const recentCopy = recent
        .map((day) => day.solved ? (day.isToday ? '◆' : '●') : '·')
        .join(' ');
      statusText
        .setWordWrapWidth(Math.max(120, this.scale.width - 24), true)
        .setAlign('center')
        .setText(
          `${copy.game.solvedDaily(
            formatActiveTime(result.result.bestTimeMs),
            copy.game.hintsCount(result.result.minHintsUsed),
            '',
          )}
${copy.game.dailyArchiveOutsideRating}
${copy.game.streakRecent(result.currentStreak, recentCopy)}`,
        )
        .setColor('#d8d1c4')
        .setVisible(true);
      completionActions = [
        {
          label: copy.game.dailyTitle,
          action: () => this.scene.start(DAILY_SCENE_KEY),
        },
        {
          label: copy.game.home,
          action: () => this.scene.start(HOME_SCENE_KEY),
        },
      ];
      renderCompletionButtons();
    };

    const showDailyPracticeCompletionState = (
      metadata: CampaignCompletionMetadata,
    ): void => {
      completionMode = true;
      currentHint = null;
      board?.setHintCellTarget(null);
      setToolbarVisible(false);
      statusText
        .setWordWrapWidth(Math.max(120, this.scale.width - 24), true)
        .setAlign('center')
        .setText(`✓ ${copy.common.solved} · ${formatActiveTime(metadata.bestTimeMs)} · ${copy.game.dailyPractice}`)
        .setColor('#d8d1c4')
        .setVisible(true);
      completionActions = [
        {
          label: copy.game.dailyTitle,
          action: () => this.scene.start(DAILY_SCENE_KEY),
        },
        {
          label: copy.game.home,
          action: () => this.scene.start(HOME_SCENE_KEY),
        },
      ];
      renderCompletionButtons();
    };

    const finishOnboarding = (): void => {
      onboardingIndex = -1;
      onboardingOpen = false;
      onboardingBlocksInteraction = false;
      onboardingBlocksTimer = false;
      board?.setInputCellTargets(null);
      if (!solved && !resetDialogOpen) {
        board?.setInputEnabled(platformGameplayActivity?.isPlatformPaused() !== true);
      }
      statusText.setVisible(true);
      relayoutOnboarding();
      resumeActiveTimer();
      syncToolbar();
    };

    function advanceOnboarding(): void {
      if (!onboardingOpen) return;
      onboardingIndex += 1;
      if (onboardingIndex >= onboardingSteps.length) {
        finishOnboarding();
        return;
      }
      applyOnboardingStep();
    }

    const applyOnboardingStep = (): void => {

      while (true) {
        const step = currentOnboardingStep();
        if (step === null) {
          finishOnboarding();
          return;
        }
        if (isOnboardingStepSatisfied(step, (x, y) => puzzle.getCellState(x, y))) {
          onboardingIndex += 1;
          continue;
        }
        break;
      }

      const step = currentOnboardingStep();
      if (step === null) {
        finishOnboarding();
        return;
      }

      statusText.setVisible(false);
      board?.setInputCellTargets(null);

      onboardingBlocksInteraction = true;
      onboardingBlocksTimer = true;
      pauseActiveTimer();
      board?.setInputCellTargets(step.cells);
      board?.setInputEnabled(platformGameplayActivity?.isPlatformPaused() !== true);

      relayoutOnboarding();
      syncToolbar();
    };

    const setActiveTool = (tool: 'wall' | 'floor'): void => {
      if (solved || resetDialogOpen) return;
      if (onboardingOpen && !onboardingAllowsTool(tool)) return;

      board?.setActiveTool(tool);
      syncToolbar();
    };

    const startFreshCampaignReplay = async (): Promise<void> => {
      if (!completedReview || profileService === null || campaignContext === null) return;

      const freshSession = PuzzleSessionService.createCampaign(
        launchData.level,
        profileService,
        undefined,
      );
      freshSession.saveNow();
      try {
        await freshSession.flush();
      } catch (error) {
        console.warn('[Dungeon Logic] Could not persist fresh campaign replay before restart; using in-memory state.', error);
      }
      if (createVersion !== this.createVersion || !this.scene.isActive()) return;
      this.scene.restart(launchData);
    };

    const closeResetDialog = (): void => {
      resetDialog?.destroy(true);
      resetDialog = null;
      resetDialogOpen = false;
      if (!solved && !onboardingOpen) {
        board?.setInputEnabled(platformGameplayActivity?.isPlatformPaused() !== true);
      }
      resumeActiveTimer();
      syncToolbar();
    };

    const relayoutResetDialog = (): void => {
      if (resetDialog === null) return;
      resetDialog.setPosition(this.scale.width / 2, this.scale.height / 2);
    };

    const showResetDialog = (): void => {
      if (resetDialogOpen || (solved && !completedReview)) return;
      resetDialogOpen = true;
      board?.setInputEnabled(false);
      pauseActiveTimer();
      syncToolbar();

      const modalChrome = calculatePuzzleChromeLayout(this.scale.width, this.scale.height);
      const width = Math.min(380, modalChrome.modalWidth);
      const height = 180;
      const container = this.add.container(this.scale.width / 2, this.scale.height / 2);
      resetDialog = container;

      const panel = this.add.rectangle(0, 0, width, height, 0x15191f, 0.98)
        .setStrokeStyle(2, 0x6b7077);
      const title = this.add.text(0, -52, copy.game.resetTitle, {
        fontFamily: 'monospace',
        fontSize: `${modalChrome.modalTitleFontSize}px`,
        color: '#f0e6d2',
        fontStyle: 'bold',
      }).setOrigin(0.5);
      const dialogCopy = this.add.text(0, -14, copy.game.resetBody, {
        fontFamily: 'monospace',
        fontSize: `${modalChrome.modalCopyFontSize}px`,
        color: '#aeb4bc',
        align: 'center',
        wordWrap: { width: width - 36 },
      }).setOrigin(0.5);

      const buttonWidth = Math.floor((width - 54) / 2);
      const cancelX = -buttonWidth / 2 - 6;
      const resetX = buttonWidth / 2 + 6;
      const buttonY = 48;
      const cancel = this.add.rectangle(cancelX, buttonY, buttonWidth, 46, 0x2a3038, 1)
        .setInteractive({ useHandCursor: true });
      const confirm = this.add.rectangle(resetX, buttonY, buttonWidth, 46, 0x63383b, 1)
        .setInteractive({ useHandCursor: true });
      const cancelLabel = this.add.text(cancelX, buttonY, copy.common.cancel, {
        fontFamily: 'monospace',
        fontSize: '15px',
        color: '#d8d1c4',
        fontStyle: 'bold',
      }).setOrigin(0.5);
      const confirmLabel = this.add.text(resetX, buttonY, copy.common.reset, {
        fontFamily: 'monospace',
        fontSize: '15px',
        color: '#f0d8d2',
        fontStyle: 'bold',
      }).setOrigin(0.5);

      cancel.on('pointerdown', () => {
        closeResetDialog();
      });
      confirm.on('pointerdown', () => {
        if (completedReview) {
          resetDialog?.destroy(true);
          resetDialog = null;
          resetDialogOpen = false;
          void startFreshCampaignReplay();
          return;
        }
        board?.reset();
        closeResetDialog();
      });

      container.add([panel, title, dialogCopy, cancel, confirm, cancelLabel, confirmLabel]);
    };

    const requestReset = (): void => {
      if (completedReview) {
        if (resetDialogOpen || hintConfirmOpen || platformGameplayActivity?.isPlatformPaused() === true) return;
        showResetDialog();
        return;
      }
      if (controlsLocked() || interaction.getEditCount() === 0) return;
      if (shouldConfirmReset(interaction.getEditCount())) {
        showResetDialog();
        return;
      }
      board?.reset();
      syncToolbar();
    };

    const handlePuzzleChanged = (): void => {
      syncToolbar();
      if (solved) return;
      if (!validatePuzzle(puzzle).isSolved) return;

      solved = true;
      board?.setInputEnabled(false);
      pauseActiveTimer();
      savePuzzleSession();
      syncToolbar();
      setToolbarVisible(false);
      currentHint = null;
      board?.setHintCellTarget(null);

      const hintsUsed = puzzleSession?.getHintsUsed() ?? transientHintsUsed;
      const metadata: CampaignCompletionMetadata = {
        bestTimeMs: puzzleSession?.getActivePlayMs() ?? activeTimer.getElapsedMs(readActiveClockMs()),
        minHintsUsed: hintsUsed,
        solveCount: 1,
        solvedWithoutHints: hintsUsed === 0,
      };

      if (launchData.context.mode === 'dev') {
        completionMode = true;
        statusText
          .setText(copy.game.solvedCampaign(
            formatActiveTime(metadata.bestTimeMs),
            copy.game.withoutHints,
            '',
            '',
          ))
          .setColor('#d8d1c4')
          .setVisible(true);
        return;
      }

      if (launchData.context.mode === 'tutorial') {
        statusText.setText('').setVisible(false);
        void this.finishTutorialLevel(
          launchData,
          createVersion,
          puzzleSession,
        ).then((result) => {
          if (result === null || createVersion !== this.createVersion) return;
          showTutorialCompletionState(result);
        });
        return;
      }

      if (launchData.context.mode === 'daily') {
        statusText.setText('').setVisible(false);
        void this.finishDailyLevel(
          launchData,
          createVersion,
          metadata,
        ).then((result) => {
          if (result === null || createVersion !== this.createVersion) return;

          if (!result.wasFirstSolve) {
            this.time.delayedCall(350, () => {
              if (createVersion !== this.createVersion) return;
              showDailyPracticeCompletionState(metadata);
            });
            return;
          }

          if (!result.ranked) {
            this.time.delayedCall(350, () => {
              if (createVersion !== this.createVersion) return;
              if (result.archive) {
                showDailyArchiveCompletionState(result);
              } else {
                showDailyAssistedCompletionState(result);
              }
            });
            return;
          }

          let leaderboardEntry: LeaderboardPlayerView | null = null;
          let resultShown = false;
          void submitRankedDailyResult(result)
            .then((entry) => {
              if (createVersion !== this.createVersion) return;
              leaderboardEntry = entry;
              if (resultShown) showDailyCompletionState(result, leaderboardEntry);
            })
            .catch((error) => {
              console.warn('[Dungeon Logic] Could not submit ranked Daily result yet.', error);
            });
          this.time.delayedCall(500, () => {
            if (createVersion !== this.createVersion) return;
            resultShown = true;
            showDailyCompletionState(result, leaderboardEntry);
          });
        });
        return;
      }

      const previousResult = profileService?.getProfile().campaign.levelResults[launchData.context.campaignLevelId];
      const newBestTime = previousResult === undefined || metadata.bestTimeMs < previousResult.bestTimeMs;
      statusText.setText('').setVisible(false);

      void this.finishCampaignLevel(
        launchData,
        createVersion,
        puzzleSession,
        metadata,
      ).then((result) => {
        if (result === null || createVersion !== this.createVersion) return;
        this.time.delayedCall(500, () => {
          if (createVersion !== this.createVersion) return;
          showCompletionState(result, metadata, newBestTime);
        });
      });
    };

    const handleEditCommitted = (): void => {
      savePuzzleSession();
      if (
        currentHint !== null
        && puzzle.getCellState(currentHint.x, currentHint.y) === currentHint.state
      ) {
        currentHint = null;
        board?.setHintCellTarget(null);
        refreshStatusText();
      }
      const step = currentOnboardingStep();
      if (
        onboardingOpen
        && step !== null
        && isOnboardingStepSatisfied(step, (x, y) => puzzle.getCellState(x, y))
      ) {
        advanceOnboarding();
      }
    };

    board = new BoardView(
      this,
      puzzle,
      interaction,
      boardLayout.originX,
      boardLayout.originY,
      boardLayout.cellSize,
      handlePuzzleChanged,
      handleEditCommitted,
    );

    const toolbarActions: Record<PuzzleToolbarButtonId, () => void> = {
      wall: () => setActiveTool('wall'),
      floor: () => setActiveTool('floor'),
      undo: () => {
        if (controlsLocked()) return;
        board?.undo();
        syncToolbar();
      },
      reset: requestReset,
      hint: showHintConfirm,
    };

    const initialToolbarState = createPuzzleToolbarState(
      'wall',
      false,
      showTouchToolButtons,
      rankedDaily ? 0 : profileService?.getFreeHintsRemaining() ?? 0,
      rankedDaily ? false : rewardedHintAvailable,
      language,
    );
    for (const buttonState of initialToolbarState.buttons) {
      const buttonLayout = toolbarLayout.buttons.find((button) => button.id === buttonState.id);
      if (buttonLayout === undefined) continue;

      const rectangle = this.add.rectangle(
        buttonLayout.x,
        buttonLayout.y,
        buttonLayout.width,
        buttonLayout.height,
        0x2a3038,
        1,
      )
        .setInteractive({ useHandCursor: true })
        .on('pointerup', toolbarActions[buttonState.id]);
      const label = this.add.text(buttonLayout.x, buttonLayout.y, buttonState.label, {
        fontFamily: 'monospace',
        fontSize: this.scale.width < 700 ? '15px' : '16px',
        color: '#d8d1c4',
        fontStyle: 'bold',
      }).setOrigin(0.5);

      toolbarVisuals.set(buttonState.id, { rectangle, label });
    }

    backText.on('pointerdown', () => {
      if (hintConfirmOpen) {
        closeHintConfirm();
        return;
      }
      if (resetDialogOpen) return;
      board?.setInputEnabled(false);
      pauseActiveTimer();
      savePuzzleSession();

      const leave = async (): Promise<void> => {
        try {
          await flushProfileState();
        } catch (error) {
          console.warn('[Dungeon Logic] Could not flush profile state before leaving; keeping dirty in-memory state.', error);
        }
        if (this.scene.isActive()) {
          this.scene.start(
            launchData.context.mode === 'daily' || launchData.context.mode === 'tutorial'
              ? HOME_SCENE_KEY
              : ARCHIVE_SCENE_KEY,
          );
        }
      };
      void leave();
    });

    helpText.on('pointerup', () => {
      if (resetDialogOpen || hintConfirmOpen || solved) return;
      board?.setInputEnabled(false);
      pauseActiveTimer();
      savePuzzleSession();
      sceneOverlayPaused = true;
      this.scene.launch(HELP_SCENE_KEY, { returnSceneKey: 'GameScene' });
      this.scene.pause();
    });

    settingsText.on('pointerup', () => {
      if (resetDialogOpen || hintConfirmOpen || rewardedHintRequestPending) return;
      board?.setInputEnabled(false);
      pauseActiveTimer();
      savePuzzleSession();
      sceneOverlayPaused = true;
      this.scene.launch(SETTINGS_SCENE_KEY, { returnSceneKey: 'GameScene' });
      this.scene.pause();
    });

    const keyboard = this.input.keyboard;
    const handleKeyDown = (event: KeyboardEvent): void => {
      if (event.repeat || controlsLocked()) return;

      switch (event.code) {
        case 'Digit1':
        case 'Numpad1':
          setActiveTool('wall');
          break;
        case 'Digit2':
        case 'Numpad2':
          setActiveTool('floor');
          break;
        case 'KeyZ':
          if (event.ctrlKey || event.metaKey) {
            event.preventDefault();
            board?.undo();
            syncToolbar();
          }
          break;
        case 'KeyR':
          requestReset();
          break;
        case 'KeyH':
          showHintConfirm();
          break;
      }
    };
    keyboard?.on('keydown', handleKeyDown);

    const handleResize = (): void => {
      if (!this.scene.isActive()) return;

      const width = this.scale.width;
      const height = this.scale.height;
      const nextChrome = calculatePuzzleChromeLayout(width, height);
      const nextSafeTop = readSafeArea('--safe-area-inset-top');
      const nextBoardLayout = calculateSafeBoardLayout(completionMode && height < 520 ? 40 : 0);
      toolbarLayout = calculatePuzzleToolbarLayout(
        width,
        height,
        readSafeArea('--safe-area-inset-bottom'),
        showTouchToolButtons,
      );

      titleText
        .setPosition(width / 2, nextChrome.titleY + nextSafeTop)
        .setFontSize(nextChrome.titleFontSize)
        .setText(getTitleLabel());
      timerText
        .setPosition(width / 2, nextChrome.titleY + nextSafeTop + (width < 700 ? 28 : 34))
        .setFontSize(Math.max(12, nextChrome.statusFontSize));
      backText
        .setPosition(nextChrome.actionInset, nextChrome.titleY + nextSafeTop)
        .setFontSize(nextChrome.actionFontSize);

      helpText
        .setPosition(width - nextChrome.actionInset, nextChrome.titleY + nextSafeTop)
        .setFontSize(nextChrome.actionFontSize)
        .setText(width < 700 ? 'ⓘ' : copy.game.rules);
      settingsText
        .setPosition(width - nextChrome.actionInset - (width < 700 ? 38 : 118), nextChrome.titleY + nextSafeTop)
        .setFontSize(Math.max(16, nextChrome.actionFontSize + 2));

      for (const buttonLayout of toolbarLayout.buttons) {
        const visual = toolbarVisuals.get(buttonLayout.id);
        if (visual === undefined) continue;
        visual.rectangle
          .setPosition(buttonLayout.x, buttonLayout.y)
          .setDisplaySize(buttonLayout.width, buttonLayout.height);
        visual.label
          .setPosition(buttonLayout.x, buttonLayout.y)
          .setFontSize(width < 700 ? 15 : 16);
      }

      const toolbarTop = Math.min(
        ...toolbarLayout.buttons.map((button) => button.y - button.height / 2),
      );
      statusText
        .setPosition(width / 2, toolbarTop - 18)
        .setFontSize(nextChrome.statusFontSize);
      if (completionMode || completedReview) {
        statusText.setWordWrapWidth(Math.max(120, width - 24), true).setAlign('center');
      }

      boardLayout = nextBoardLayout;
      board?.relayout(
        boardLayout.originX,
        boardLayout.originY,
        boardLayout.cellSize,
      );
      relayoutResetDialog();
      relayoutOnboarding();
      if (hintConfirmOpen) renderHintConfirm();
      if (completionMode) renderCompletionButtons();
      syncToolbar();
    };

    const handleVisibilityChange = (): void => {
      if (typeof document === 'undefined') return;

      if (document.hidden) {
        pauseActiveTimer();
        savePuzzleSession();
        void flushProfileState().catch((error) => {
          console.warn('[Dungeon Logic] Could not flush profile state on visibility loss; keeping dirty in-memory state.', error);
        });
        return;
      }

      resumeActiveTimer();
    };
    if (typeof document !== 'undefined') {
      document.addEventListener('visibilitychange', handleVisibilityChange);
    }

    const restoreBoardInputAfterPlatformResume = (): void => {
      if (solved || resetDialogOpen || hintConfirmOpen || sceneOverlayPaused) {
        board?.setInputEnabled(false);
        return;
      }
      if (!onboardingOpen) {
        board?.setInputEnabled(true);
        return;
      }

      board?.setInputEnabled(currentOnboardingStep() !== null);
    };

    const unsubscribePlatformLifecycle = platformServices?.lifecycle.subscribe({
      onPause: () => {
        platformGameplayActivity?.pauseFromPlatform();
        board?.setInputEnabled(false);
        pauseActiveTimer(false);
        savePuzzleSession();
        void flushProfileState().catch((error) => {
          console.warn('[Dungeon Logic] Could not flush profile state on platform pause; keeping dirty in-memory state.', error);
        });
        syncToolbar();
      },
      onResume: () => {
        const canResume = internalTimerMayRun();
        platformGameplayActivity?.resumeFromPlatform(canResume);
        if (platformGameplayActivity?.isPlatformPaused() !== true) {
          restoreBoardInputAfterPlatformResume();
        }
        resumeActiveTimer(false);
        syncToolbar();
      },
    }) ?? (() => {});

    const handleSceneResume = (): void => {
      sceneOverlayPaused = false;
      const latestLanguage = this.getPlayerProfileService().getProfile().settings.language;
      if (latestLanguage !== language) {
        if (campaignContext !== null || tutorialContext !== null) {
          this.scene.restart(launchData);
          return;
        }
        language = latestLanguage;
        copy = getUiCopy(language);
        titleText.setText(getTitleLabel());
        backText.setText(copy.game.back);
        helpText.setText(this.scale.width < 700 ? 'ⓘ' : copy.game.rules);
        refreshStatusText();
      }
      if (onboardingOpen) {
        applyOnboardingStep();
        return;
      }
      if (!solved && !resetDialogOpen) {
        board?.setInputEnabled(platformGameplayActivity?.isPlatformPaused() !== true);
      }
      resumeActiveTimer();
      syncToolbar();
    };
    this.events.on(Phaser.Scenes.Events.RESUME, handleSceneResume);

    const timerRefresh = this.time.addEvent({
      delay: 250,
      loop: true,
      callback: updateTimerText,
    });
    const hintUiRefresh = this.time.addEvent({
      delay: 1000,
      loop: true,
      callback: () => {
        if (solved || completionMode || onboardingOpen || hintConfirmOpen || resetDialogOpen) return;
        syncToolbar();
        refreshStatusText();
      },
    });

    this.scale.on(Phaser.Scale.Events.RESIZE, handleResize);
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, () => {
      pauseActiveTimer();
      timerRefresh.destroy();
      hintUiRefresh.destroy();
      this.scale.off(Phaser.Scale.Events.RESIZE, handleResize);
      keyboard?.off('keydown', handleKeyDown);
      this.events.off(Phaser.Scenes.Events.RESUME, handleSceneResume);
      unsubscribePlatformLifecycle();
      if (typeof document !== 'undefined') {
        document.removeEventListener('visibilitychange', handleVisibilityChange);
      }
    });

    if (completedReview) {
      board.setInputCellTarget(null);
      board.setInputEnabled(false);
      updateTimerText();
      refreshStatusText();
      syncToolbar();
    } else if (onboardingOpen) {
      applyOnboardingStep();
    } else {
      board.setInputCellTarget(null);
      board.setInputEnabled(platformGameplayActivity?.isPlatformPaused() !== true);
      resumeActiveTimer();
      syncToolbar();
    }

    void platformServices?.readiness.ready();
  }

  private async finishCampaignLevel(
    launchData: GameSceneData,
    createVersion: number,
    puzzleSession: PuzzleSessionService | null,
    resultMetadata: CampaignCompletionMetadata,
  ): Promise<CampaignCompletionResult | null> {
    const service = this.getCampaignService();
    const result = await completeGameLaunch(launchData, service, resultMetadata);

    if (createVersion !== this.createVersion || result === null) return null;

    if (puzzleSession !== null) {
      puzzleSession.clearActivePuzzle();
      try {
        await puzzleSession.flush();
      } catch (error) {
        console.warn('[Dungeon Logic] Campaign completion cleared the active puzzle in memory, but the clear could not be flushed yet.', error);
      }
    }

    if (createVersion !== this.createVersion) return null;
    return result;
  }

  private async finishTutorialLevel(
    launchData: GameSceneData,
    createVersion: number,
    puzzleSession: PuzzleSessionService | null,
  ): Promise<TutorialCompletionResult | null> {
    if (launchData.context.mode !== 'tutorial') return null;
    const service = this.getTutorialService();
    const result = await service.completeLevel(launchData.context.tutorialLevelId);
    if (createVersion !== this.createVersion) return null;

    if (puzzleSession !== null) {
      puzzleSession.clearActivePuzzle();
      try {
        await puzzleSession.flush();
      } catch (error) {
        console.warn('[Dungeon Logic] Tutorial completion cleared the active puzzle in memory, but the clear could not be flushed yet.', error);
      }
    }

    if (createVersion !== this.createVersion) return null;
    return result;
  }

  private async finishDailyLevel(
    launchData: GameSceneData,
    createVersion: number,
    metadata: CampaignCompletionMetadata,
  ): Promise<DailyCompletionResult | null> {
    const service = this.getDailyService();
    const result = await completeDailyGameLaunch(
      launchData,
      service,
      metadata.bestTimeMs,
      metadata.minHintsUsed,
    );
    if (createVersion !== this.createVersion) return null;
    return result;
  }

  private async startNextLevel(
    nextLevel: NonNullable<CampaignCompletionResult['recommendedNextLevel']>,
    service: CampaignService,
    createVersion: number,
  ): Promise<void> {
    const nextData = await createNextCampaignGameSceneData(nextLevel, service);
    if (createVersion !== this.createVersion) return;
    this.scene.restart(nextData);
  }

  private getPlayerProfileService(): PlayerProfileService {
    const service = this.registry.get(PLAYER_PROFILE_SERVICE_REGISTRY_KEY) as unknown;
    if (!(service instanceof PlayerProfileService)) {
      throw new Error('Profile-backed GameScene requires PlayerProfileService in Phaser registry.');
    }
    return service;
  }

  private getTutorialService(): TutorialService {
    const service = this.registry.get(TUTORIAL_SERVICE_REGISTRY_KEY) as unknown;
    if (!(service instanceof TutorialService)) {
      throw new Error('Tutorial GameScene requires TutorialService in Phaser registry.');
    }
    return service;
  }

  private getDailyService(): DailyService {
    const service = this.registry.get(DAILY_SERVICE_REGISTRY_KEY) as unknown;
    if (!(service instanceof DailyService)) {
      throw new Error('Daily GameScene requires DailyService in Phaser registry.');
    }
    return service;
  }

  private getCampaignService(): CampaignService {
    const service = this.registry.get(CAMPAIGN_SERVICE_REGISTRY_KEY) as unknown;
    if (!(service instanceof CampaignService)) {
      throw new Error('Campaign GameScene requires CampaignService in Phaser registry.');
    }
    return service;
  }
}
