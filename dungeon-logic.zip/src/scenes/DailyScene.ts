import Phaser from 'phaser';

import { ANALYTICS_SERVICE_REGISTRY_KEY, type AnalyticsService } from '../analytics/AnalyticsService';

import { getAudioFeedback } from '../audio/AudioFeedbackService';
import type { DailyEntry } from '../content/daily/types';
import {
  DAILY_SERVICE_REGISTRY_KEY,
  DailyService,
  type DailyArchiveEntry,
  type DailyTodaySnapshot,
} from '../daily/DailyService';
import { getUiCopy, type UiCopy } from '../i18n/UiCopy';
import {
  calculateAvailableViewport,
  readCssSafeAreaInsets,
  type AvailableViewport,
} from '../runtime/AvailableViewport';
import {
  PLAYER_PROFILE_SERVICE_REGISTRY_KEY,
  PlayerProfileService,
} from '../profile/PlayerProfileService';
import {
  createDailyHubCalendarMonth,
  getInitialDailyHubCalendarMonth,
  shiftDailyHubCalendarMonth,
  type DailyHubCalendarDayState,
} from '../runtime/DailyHubCalendar';
import {
  calculateDailyHubLayout,
  getDailyCalendarRowCount,
} from '../runtime/DailyHubLayout';
import { createDailyGameSceneData } from '../runtime/GameLaunch';
import { createPrimaryActionButton } from '../runtime/PrimaryActionButton';
import { createMaterialActionButton } from '../runtime/MaterialActionButton';
import { createHeaderActionButton } from '../runtime/HeaderActionButton';
import { createSlateSurface } from '../runtime/SlateSurface';
import { createQuietInset } from '../runtime/QuietInset';
import { createMetaPageHeader } from '../runtime/MetaPageHeader';
import { MetaPointerGate } from '../runtime/MetaPointerGate';
import {
  clampMetaScrollY,
  getMetaScrollMaxY,
  isMetaScrollDrag,
} from '../runtime/MetaScroll';
import { HOME_SCENE_KEY } from '../runtime/MetaSelectors';
import { createSceneBackground } from '../runtime/SceneBackground';
import { UI_ICON_KEYS } from '../runtime/UiIcons';
import { createDailyLevelPreview } from '../runtime/DailyLevelPreview';
import type { DailyProfileState } from '../profile/types';
import { drawLevelThumbnail } from '../view/LevelThumbnailRenderer';
import { LEADERBOARD_SCENE_KEY } from './LeaderboardScene';

export const DAILY_SCENE_KEY = 'DailyScene';

const CALENDAR_STATE_STYLE: Readonly<Record<DailyHubCalendarDayState, {
  readonly fill: number;
  readonly alpha: number;
  readonly stroke: number;
  readonly strokeAlpha: number;
  readonly text: string;
}>> = {
  unavailable: { fill: 0x111c2e, alpha: 0.86, stroke: 0x65748a, strokeAlpha: 0.26, text: '#9aa9bc' },
  'archive-unsolved': { fill: 0x1a2a40, alpha: 0.98, stroke: 0x8192a8, strokeAlpha: 0.58, text: '#e1e7f1' },
  'archive-solved': { fill: 0x203449, alpha: 0.98, stroke: 0x92c9bb, strokeAlpha: 0.65, text: '#dff2e9' },
  today: { fill: 0x27354b, alpha: 1, stroke: 0xe4b65d, strokeAlpha: 1, text: '#ffe2a4' },
  future: { fill: 0x152238, alpha: 0.96, stroke: 0x788aa1, strokeAlpha: 0.48, text: '#aab7ca' },
};

const DAILY_CARD_RADIUS = 8;
const CURRENT_GLOW_TEXTURE_SCALE = 3;


export class DailyScene extends Phaser.Scene {
  private launchPending = false;
  private contentBottom = 0;
  private scrollMaxY = 0;
  private scrollPointerId: number | null = null;
  private scrollStartPointerY = 0;
  private scrollStartCameraY = 0;
  private scrollGestureDragged = false;
  private lastDraggedPointerId: number | null = null;
  private lastDragEndedAtMs = 0;
  private readonly pointerGate = new MetaPointerGate();

  constructor() {
    super(DAILY_SCENE_KEY);
  }

  create(): void {
    this.launchPending = false;
    this.contentBottom = 0;
    this.scrollMaxY = 0;
    this.pointerGate.reset();
    this.cameras.main.setScroll(0, 0);

    const sceneBackground = createSceneBackground(this, 'meta');
    sceneBackground.image.setScrollFactor(0);

    const profile = this.getProfileService().getProfile();
    const copy = getUiCopy(profile.settings.language);
    const analytics = this.registry.get(ANALYTICS_SERVICE_REGISTRY_KEY) as AnalyticsService | undefined;
    analytics?.screenView('daily');
    const availableViewport = this.getAvailableViewport();
    const shellLayout = calculateDailyHubLayout(availableViewport.width, availableViewport.height, 6);
    const { narrow } = shellLayout;
    const summaryX = shellLayout.sideBySide ? availableViewport.x + availableViewport.width * 0.27 : availableViewport.centerX;
    const calendarX = shellLayout.sideBySide ? availableViewport.x + availableViewport.width * 0.73 : availableViewport.centerX;


    createMetaPageHeader(this, {
      title: copy.dailyHub.title,
      backLabel: copy.common.back,
      backButton: true,
      fixedBack: true,
      viewport: availableViewport,
      onBack: (pointer) => {
        if (!this.shouldActivatePointer(pointer)) return;
        this.scene.start(HOME_SCENE_KEY);
      },
    });

    const loadingShell = this.add.container(0, 0);
    loadingShell.add(createSlateSurface(
      this,
      summaryX,
      availableViewport.y + shellLayout.todayCardTop + shellLayout.todayHeight / 2,
      shellLayout.contentWidth,
      shellLayout.todayHeight,
    ));
    const loading = this.add.text(
      summaryX,
      availableViewport.y + shellLayout.todayCardTop + shellLayout.todayHeight / 2,
      copy.common.loading,
      {
      fontFamily: "'Balsamiq Sans', sans-serif",
      fontSize: shellLayout.density === 'ultra' ? '11px' : narrow ? '13px' : '16px',
        color: '#d0d9e8',
      },
    ).setOrigin(0.5);
    loadingShell.add(loading);
    const actionHeight = narrow ? (shellLayout.density === 'tight' ? 50 : 58) : shellLayout.density === 'tight' ? 56 : 66;
    const actionY = availableViewport.y + shellLayout.todayCardTop + shellLayout.todayHeight + 12 + actionHeight / 2;
    const actionWidths = narrow ? [Math.min(shellLayout.contentWidth - 28, 330), Math.min(shellLayout.contentWidth - 28, 330)]
      : shellLayout.sideBySide ? [220, 220] : [290, 238];
    const actionGap = narrow ? 8 : 14;
    const actionGroupWidth = actionWidths[0]! + actionGap + actionWidths[1]!;
    for (let index = 0; index < 2; index += 1) {
      const x = narrow ? summaryX : summaryX - actionGroupWidth / 2
        + (index === 0 ? actionWidths[0]! / 2 : actionWidths[0]! + actionGap + actionWidths[1]! / 2);
      loadingShell.add(createQuietInset(this, {
        x,
        y: narrow ? actionY + index * (actionHeight + actionGap) : actionY,
        width: actionWidths[index]!,
        height: actionHeight,
        fillAlpha: 0.68,
        borderAlpha: 0.2,
      }));
    }
    const loadingMonth = this.add.text(calendarX,
      availableViewport.y + shellLayout.monthHeaderY, '···', {
        fontFamily: "'Balsamiq Sans', sans-serif",
        fontSize: narrow ? '14px' : '17px',
        color: '#a9b8ca',
      }).setOrigin(0.5);
    loadingShell.add(loadingMonth);
    const loadingGridWidth = shellLayout.cellSize * 7 + shellLayout.columnGap * 6;
    for (let row = 0; row < 6; row += 1) {
      for (let column = 0; column < 7; column += 1) {
        const x = calendarX - loadingGridWidth / 2
          + shellLayout.cellSize / 2 + column * (shellLayout.cellSize + shellLayout.columnGap);
        const y = availableViewport.y + shellLayout.gridTopY + shellLayout.cellSize / 2 + row * shellLayout.rowPitch;
        loadingShell.add(createQuietInset(this, {
          x, y, width: shellLayout.cellSize, height: shellLayout.cellSize,
          radius: 6, fillAlpha: 0.42, borderAlpha: 0.12,
        }));
      }
    }

    const renderVersion = Date.now();
    this.registry.set('daily-scene-render-version', renderVersion);
    void Promise.all([
      this.getDailyService().getToday(),
      this.getDailyService().getArchive(),
    ]).then(([today, archiveRows]) => {
      if (!this.scene.isActive() || this.registry.get('daily-scene-render-version') !== renderVersion) return;
      loadingShell.destroy(true);
      this.renderContent(
        today,
        archiveRows,
        this.getProfileService().getProfile().daily,
        copy,
      );
      this.setupMetaScroll();
    }).catch((error) => {
      console.warn('[Dungeon Logic] Could not load Daily hub.', error);
      if (!this.scene.isActive()) return;
      loadingShell.destroy(true);
      this.renderContent(null, [], this.getProfileService().getProfile().daily, copy);
    });

    this.setupPointerOwnership();

    const handleResize = (): void => {
      sceneBackground.sync();
      if (this.scene.isActive()) this.scene.restart();
    };
    this.scale.on(Phaser.Scale.Events.RESIZE, handleResize);
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, () => {
      this.scale.off(Phaser.Scale.Events.RESIZE, handleResize);
    });
  }

  private renderContent(
    today: DailyTodaySnapshot | null,
    archiveRows: readonly DailyArchiveEntry[],
    dailyProfile: DailyProfileState,
    copy: UiCopy,
  ): void {
    const availableViewport = this.getAvailableViewport();
    const shellLayout = calculateDailyHubLayout(availableViewport.width, availableViewport.height, 6);
    const { narrow, density } = shellLayout;
    const width = shellLayout.contentWidth;
    const centerX = shellLayout.sideBySide ? availableViewport.x + availableViewport.width * 0.27 : availableViewport.centerX;
    const calendarX = shellLayout.sideBySide ? availableViewport.x + availableViewport.width * 0.73 : availableViewport.centerX;
    const viewportTop = availableViewport.y;
    const dailyEntries = this.getDailyService().getEntries();

    const todayHeight = shellLayout.todayHeight;
    const todayCardTop = viewportTop + shellLayout.todayCardTop;
    const todayCardCenterY = todayCardTop + todayHeight / 2;
    createSlateSurface(this, centerX, todayCardCenterY, width, todayHeight);

    if (today?.entry === null || today === null) {
      this.add.text(centerX, todayCardCenterY, copy.dailyHub.todayUnavailable, {
        fontFamily: "'Balsamiq Sans', sans-serif",
        fontSize: narrow ? '14px' : '17px',
        color: '#d0d9e8',
        align: 'center',
        wordWrap: { width: width - 40 },
      }).setOrigin(0.5);
    } else {
      const entry = today.entry;
      const solved = today.solved && today.result !== null;
      const pad = narrow ? 18 : 26;
      const left = centerX - width / 2 + pad;
      const right = centerX + width / 2 - pad;
      const dateY = todayCardTop + (todayHeight < 90 ? 25 : narrow ? 27 : 32);
      const secondaryY = todayCardTop + (todayHeight < 90 ? 53 : narrow ? 63 : 70);
      const status = solved
        ? (today.result!.minHintsUsed > 0
          ? copy.dailyHub.todaySolvedOutsideRating(this.formatTime(today.result!.bestTimeMs))
          : copy.dailyHub.todaySolved(this.formatTime(today.result!.bestTimeMs)))
        : copy.dailyHub.todayUnsolved;
      this.add.text(left, dateY, this.formatDate(today.dateKey), {
        fontFamily: "'Balsamiq Sans', sans-serif",
        fontSize: narrow ? '17px' : '21px',
        color: '#f4ead7',
        fontStyle: 'bold',
      }).setOrigin(0, 0.5);
      const streak = copy.home.dailyStreak(today.currentStreak);
      this.add.text(right, dateY, streak, {
        fontFamily: "'Balsamiq Sans', sans-serif",
        fontSize: narrow ? '13px' : '17px',
        color: '#e4bd70',
        fontStyle: 'bold',
      }).setOrigin(1, 0.5);
      this.add.text(left, secondaryY, status, {
        fontFamily: "'Balsamiq Sans', sans-serif",
        fontSize: narrow ? '12px' : '15px',
        color: '#d1dbea',
        wordWrap: { width: width - pad * 2 },
      }).setOrigin(0, 0.5);

      const actionHeight = narrow ? (density === 'tight' ? 50 : 58) : density === 'tight' ? 56 : 66;
      const gap = narrow ? 8 : 14;
      const actionY = todayCardTop + todayHeight + 12 + actionHeight / 2;
      const playWidth = narrow ? Math.min(width - 28, 330) : shellLayout.sideBySide ? 220 : 290;
      const leaderboardWidth = narrow ? playWidth : shellLayout.sideBySide ? 220 : 238;
      const groupWidth = playWidth + gap + leaderboardWidth;
      const playX = narrow ? centerX : centerX - groupWidth / 2 + playWidth / 2;
      const leaderboardX = narrow ? centerX : centerX + groupWidth / 2 - leaderboardWidth / 2;

      this.createTodayActionButton({
        x: playX,
        y: actionY,
        width: playWidth,
        height: actionHeight,
        label: solved ? copy.dailyHub.replayToday : copy.dailyHub.playToday,
        icon: 'play',
        accentFrame: !solved,
        onActivate: (pointer) => {
          if (!this.shouldActivatePointer(pointer)) return;
          void this.launchDaily(entry);
        },
      });
      this.createTodayActionButton({
        x: leaderboardX,
        y: narrow ? actionY + actionHeight + gap : actionY,
        width: leaderboardWidth,
        height: actionHeight,
        label: copy.dailyHub.leaderboard,
        icon: 'statistics',
        accentFrame: solved,
        onActivate: (pointer) => {
          if (!this.shouldActivatePointer(pointer)) return;
          this.scene.start(LEADERBOARD_SCENE_KEY, { dailyId: entry.id, dateKey: today.dateKey });
        },
      });
    }
    if (today === null) {
      this.add.text(calendarX, viewportTop + shellLayout.monthHeaderY, copy.dailyHub.archiveEmpty, {
        fontFamily: "'Balsamiq Sans', sans-serif",
        fontSize: density === 'ultra' ? '9px' : narrow ? '12px' : '14px',
        color: '#65728a',
      }).setOrigin(0.5);
      this.contentBottom = viewportTop + shellLayout.monthHeaderY + 48;
      this.scrollMaxY = this.getScrollMaxY(this.contentBottom);
      return;
    }

    const calendarContainer = this.add.container(0, 0);
    let selectedMonth = getInitialDailyHubCalendarMonth(dailyEntries, today.dateKey);

    const renderCalendarMonth = (): void => {
      calendarContainer.removeAll(true);
      const calendar = createDailyHubCalendarMonth(
        dailyEntries,
        archiveRows,
        today,
        selectedMonth.year,
        selectedMonth.month,
      );
      selectedMonth = { year: calendar.year, month: calendar.month };

      const calendarRows = getDailyCalendarRowCount(calendar.leadingEmptyDays, calendar.days.length);
      const layout = calculateDailyHubLayout(availableViewport.width, availableViewport.height, calendarRows);
      const gridWidth = layout.cellSize * 7 + layout.columnGap * 6;
      const monthLabel = `${copy.stats.months[calendar.month - 1]} ${calendar.year}`;

      const monthText = this.add.text(calendarX, viewportTop + layout.monthHeaderY, monthLabel, {
        fontFamily: "'Balsamiq Sans', sans-serif",
        fontSize: layout.density === 'ultra' ? '10px' : layout.density === 'tight' ? '12px' : narrow ? '14px' : '17px',
        color: '#f4ead7',
        fontStyle: 'bold',
      }).setOrigin(0.5);
      calendarContainer.add(monthText);

      const createMonthArrow = (direction: -1 | 1, enabled: boolean): void => {
        const maxArrowOffset = layout.density === 'ultra' ? 180 : narrow ? 156 : 220;
        const x = calendarX + direction * Math.min(Math.max(34, gridWidth / 2 - 12), maxArrowOffset);
        const size = layout.density === 'ultra' ? 32 : narrow ? 38 : 44;
        const arrow = createHeaderActionButton(this, {
          x,
          y: viewportTop + layout.monthHeaderY,
          width: size,
          height: size,
          radius: 8,
          iconKey: UI_ICON_KEYS.back,
          iconSize: Math.round(size * 0.44),
          onActivate: (pointer) => {
            if (!enabled || !this.shouldActivatePointer(pointer)) return;
            selectedMonth = shiftDailyHubCalendarMonth(
              dailyEntries,
              today.dateKey,
              calendar.year,
              calendar.month,
              direction,
            );
            renderCalendarMonth();
          },
        });
        if (direction > 0) arrow.icon.setRotation(Math.PI);
        if (!enabled) {
          arrow.hit.disableInteractive();
          arrow.background.setAlpha(0.45);
          arrow.icon.setAlpha(0.45);
        }
        calendarContainer.add([arrow.background, arrow.icon, arrow.hit]);
      };
      createMonthArrow(-1, calendar.canGoPrevious);
      createMonthArrow(1, calendar.canGoNext);

      copy.stats.weekdays.forEach((weekday, column) => {
        const x = calendarX - gridWidth / 2 + layout.cellSize / 2 + column * (layout.cellSize + layout.columnGap);
        const text = this.add.text(x, viewportTop + layout.weekdaysY, weekday, {
          fontFamily: "'Balsamiq Sans', sans-serif",
          fontSize: layout.density === 'ultra' ? '9px' : layout.density === 'tight' ? '10px' : narrow ? '11px' : '13px',
          color: '#bac6d6',
          fontStyle: 'bold',
        }).setOrigin(0.5);
        calendarContainer.add(text);
      });

      calendar.days.forEach((day) => {
        const position = calendar.leadingEmptyDays + day.day - 1;
        const column = position % 7;
        const row = Math.floor(position / 7);
        const x = calendarX - gridWidth / 2 + layout.cellSize / 2 + column * (layout.cellSize + layout.columnGap);
        const cellY = viewportTop + layout.gridTopY + layout.cellSize / 2 + row * layout.rowPitch;
        const numberY = cellY - layout.cellSize / 2 + Math.max(3, Math.round(layout.cellSize * 0.08));
        const style = CALENDAR_STATE_STYLE[day.state];
        const radius = Math.min(DAILY_CARD_RADIUS, Math.max(5, Math.floor(layout.cellSize * 0.14)));

        if (day.state === 'today') {
          this.drawDailyCurrentGlow(calendarContainer, x, cellY, layout.cellSize, style.stroke, radius);
        }

        this.drawRoundedDailyCard(
          calendarContainer,
          x,
          cellY + 2,
          layout.cellSize,
          layout.cellSize,
          0x040912,
          day.state === 'unavailable' ? 0.1 : 0.2,
          0x000000,
          0,
          0,
          radius,
        );
        this.drawRoundedDailyCard(
          calendarContainer,
          x,
          cellY,
          layout.cellSize,
          layout.cellSize,
          style.fill,
          style.alpha,
          style.stroke,
          style.strokeAlpha,
          day.state === 'today' ? 2 : 1,
          radius,
        );

        let previewStatus: 'unstarted' | 'started' | 'completed' | null = null;

        if (day.state === 'unavailable') {
          this.drawDailyUnavailableMarker(calendarContainer, x, cellY, layout.cellSize);
        } else if (day.state === 'future') {
          const iconSize = Math.max(16, Math.floor(layout.cellSize * 0.34));
          const lock = this.add.image(x, cellY, UI_ICON_KEYS.lock)
            .setDisplaySize(iconSize, iconSize)
            .setTint(0x7f8ba2)
            .setAlpha(0.82);
          calendarContainer.add(lock);
        } else if (day.entry !== null) {
          const preview = createDailyLevelPreview(day.entry, dailyProfile);
          previewStatus = preview.status;

          if (preview.status === 'unstarted') {
            this.drawRoundedDailyCard(
              calendarContainer,
              x,
              cellY,
              Math.max(1, layout.cellSize - 6),
              Math.max(1, layout.cellSize - 6),
              day.state === 'today' ? 0x304055 : 0x26364b,
              day.state === 'today' ? 0.86 : 0.76,
              0x000000,
              0,
              0,
              Math.max(4, radius - 2),
            );
            const iconSize = Math.max(17, Math.floor(layout.cellSize * 0.36));
            const question = this.add.image(x, cellY, UI_ICON_KEYS.question)
              .setDisplaySize(iconSize, iconSize)
              .setTint(day.state === 'today' ? 0xf0bd63 : 0xf4ead7)
              .setAlpha(0.9);
            calendarContainer.add(question);
          } else {
            const thumbnail = drawLevelThumbnail(
              this,
              day.entry.level,
              preview.walls,
              { x, y: cellY, width: layout.cellSize, height: layout.cellSize },
              { showIncompleteOverlay: preview.showIncompleteOverlay },
            );
            calendarContainer.add(thumbnail);
          }

          // Redraw the rounded state border above the thumbnail so it stays crisp.
          this.drawRoundedDailyCard(
            calendarContainer,
            x,
            cellY,
            layout.cellSize,
            layout.cellSize,
            0x000000,
            0,
            style.stroke,
            style.strokeAlpha,
            day.state === 'today' ? 2 : 1,
            radius,
          );
        }

        const playableDay = (day.state === 'today' || day.state === 'archive-unsolved' || day.state === 'archive-solved') && day.entry !== null;
        const hoverOverlay = this.drawRoundedDailyOverlay(
          calendarContainer,
          x,
          cellY,
          Math.max(1, layout.cellSize - 6),
          Math.max(1, layout.cellSize - 6),
          0x40577f,
          0.16,
          Math.max(4, radius - 2),
        ).setVisible(false);

        if (day.state === 'today') {
          this.drawDailyStateMarker(calendarContainer, x, cellY, layout.cellSize);
        }
        if (day.state === 'archive-solved' || previewStatus === 'completed') {
          this.drawDailyCompletedCheck(calendarContainer, x, cellY, layout.cellSize);
        }

        const number = this.add.text(x, numberY, String(day.day), {
          fontFamily: "'Balsamiq Sans', sans-serif",
          fontSize: layout.density === 'ultra' ? '9px' : layout.density === 'tight' ? '10px' : narrow ? '11px' : '13px',
          color: style.text,
          fontStyle: day.state === 'today' ? 'bold' : 'normal',
        }).setOrigin(0.5, 0);
        calendarContainer.add(number);

        if (playableDay) {
          const cellHit = this.add.zone(x, cellY, layout.cellSize, layout.cellSize)
            .setInteractive({ useHandCursor: true });
          calendarContainer.add(cellHit);
          cellHit
            .on('pointerover', () => {
              hoverOverlay.setAlpha(0.16).setVisible(true);
            })
            .on('pointerout', () => {
              hoverOverlay.setVisible(false);
            })
            .on('pointerdown', () => {
              hoverOverlay.setAlpha(0.28).setVisible(true);
            })
            .on('pointerup', (pointer: Phaser.Input.Pointer) => {
              hoverOverlay.setAlpha(0.16).setVisible(true);
              if (!this.shouldActivatePointer(pointer)) return;
              getAudioFeedback(this).play('ui-click');
              void this.launchDaily(day.entry!);
            });
        }
      });

      this.contentBottom = viewportTop + layout.contentBottom;
      this.scrollMaxY = this.getScrollMaxY(this.contentBottom);
      this.cameras.main.setScroll(0, clampMetaScrollY(this.cameras.main.scrollY, this.scrollMaxY));
    };

    renderCalendarMonth();
  }

  private drawRoundedDailyCard(
    container: Phaser.GameObjects.Container,
    x: number,
    y: number,
    width: number,
    height: number,
    fillColor: number,
    fillAlpha: number,
    strokeColor: number,
    strokeAlpha: number,
    strokeWidth: number,
    radius: number,
  ): Phaser.GameObjects.Graphics {
    const graphics = this.add.graphics();
    const left = x - width / 2;
    const top = y - height / 2;
    graphics.fillStyle(fillColor, fillAlpha);
    graphics.fillRoundedRect(left, top, width, height, radius);
    if (strokeWidth > 0 && strokeAlpha > 0) {
      graphics.lineStyle(strokeWidth, strokeColor, strokeAlpha);
      graphics.strokeRoundedRect(left, top, width, height, radius);
    }
    container.add(graphics);
    return graphics;
  }

  private drawRoundedDailyOverlay(
    container: Phaser.GameObjects.Container,
    x: number,
    y: number,
    width: number,
    height: number,
    fillColor: number,
    fillAlpha: number,
    radius: number,
  ): Phaser.GameObjects.Graphics {
    return this.drawRoundedDailyCard(
      container,
      x,
      y,
      width,
      height,
      fillColor,
      fillAlpha,
      fillColor,
      0,
      0,
      radius,
    );
  }

  private drawDailyCurrentGlow(
    container: Phaser.GameObjects.Container,
    x: number,
    y: number,
    size: number,
    strokeColor: number,
    radius: number,
  ): void {
    const padding = Math.max(22, Math.round(size * 0.42));
    const logicalSize = Math.ceil(size + padding * 2);
    const textureKey = `daily-current-glow-${Math.round(size)}-${strokeColor.toString(16)}`;

    if (!this.textures.exists(textureKey)) {
      const canvas = document.createElement('canvas');
      canvas.width = logicalSize * CURRENT_GLOW_TEXTURE_SCALE;
      canvas.height = logicalSize * CURRENT_GLOW_TEXTURE_SCALE;
      const context = canvas.getContext('2d');
      if (context !== null) {
        context.scale(CURRENT_GLOW_TEXTURE_SCALE, CURRENT_GLOW_TEXTURE_SCALE);
        const color = `#${strokeColor.toString(16).padStart(6, '0')}`;
        context.fillStyle = color;
        context.shadowColor = color;
        context.shadowBlur = Math.max(17, size * 0.3) * CURRENT_GLOW_TEXTURE_SCALE;
        context.globalAlpha = 0.64;
        this.traceDailyRoundedCanvasRect(context, padding, padding, size, size, radius);
        context.fill();
        context.globalAlpha = 1;
      }
      this.textures.addCanvas(textureKey, canvas);
    }

    const glow = this.add.image(x, y, textureKey)
      .setDisplaySize(logicalSize, logicalSize)
      .setAlpha(0.24);
    container.add(glow);
  }

  private traceDailyRoundedCanvasRect(
    context: CanvasRenderingContext2D,
    x: number,
    y: number,
    width: number,
    height: number,
    radius: number,
  ): void {
    const r = Math.min(radius, width / 2, height / 2);
    context.beginPath();
    context.moveTo(x + r, y);
    context.lineTo(x + width - r, y);
    context.quadraticCurveTo(x + width, y, x + width, y + r);
    context.lineTo(x + width, y + height - r);
    context.quadraticCurveTo(x + width, y + height, x + width - r, y + height);
    context.lineTo(x + r, y + height);
    context.quadraticCurveTo(x, y + height, x, y + height - r);
    context.lineTo(x, y + r);
    context.quadraticCurveTo(x, y, x + r, y);
    context.closePath();
  }

  private drawDailyStateMarker(
    container: Phaser.GameObjects.Container,
    x: number,
    y: number,
    size: number,
  ): void {
    const marker = this.add.rectangle(
      x + size / 2 - Math.max(9, Math.round(size * 0.17)),
      y - size / 2 + Math.max(9, Math.round(size * 0.17)),
      Math.max(6, Math.round(size * 0.12)),
      Math.max(6, Math.round(size * 0.12)),
      0xf0bd63,
      0.96,
    ).setRotation(Math.PI / 4);
    container.add(marker);
  }

  private drawDailyUnavailableMarker(
    container: Phaser.GameObjects.Container,
    x: number,
    y: number,
    size: number,
  ): void {
    const marker = this.add.rectangle(
      x,
      y,
      Math.max(8, Math.round(size * 0.22)),
      Math.max(2, Math.round(size * 0.045)),
      0x9aabc1,
      0.88,
    );
    container.add(marker);
  }

  private drawDailyCompletedCheck(
    container: Phaser.GameObjects.Container,
    x: number,
    y: number,
    size: number,
  ): void {
    const iconSize = Math.max(16, Math.floor(size * 0.31));
    const iconX = x + size / 2 - 3;
    const iconY = y + size / 2 - 3;
    const backingRadius = iconSize * 0.39;
    const backing = this.add.circle(iconX, iconY, backingRadius, 0x0d1b2d, 1);
    const check = this.add.image(iconX, iconY, UI_ICON_KEYS.check)
      .setDisplaySize(iconSize, iconSize)
      .setTint(0x73d0bd);
    container.add([backing, check]);
  }

  private createTodayActionButton(options: {
    readonly x: number;
    readonly y: number;
    readonly width: number;
    readonly height: number;
    readonly label: string;
    readonly icon: 'play' | 'statistics';
    readonly accentFrame: boolean;
    readonly onActivate: (pointer: Phaser.Input.Pointer) => void;
  }): void {
    if (options.accentFrame) {
      createPrimaryActionButton(this, {
        x: options.x,
        y: options.y,
        width: options.width,
        height: options.height,
        label: options.label,
        iconKey: options.icon === 'play' ? 'home-menu-icon-play' : 'home-menu-icon-statistics',
        compact: false,
        onActivate: options.onActivate,
      });
      return;
    }

    createMaterialActionButton(this, {
      x: options.x,
      y: options.y,
      width: options.width,
      height: options.height,
      label: options.label,
      iconKey: options.icon === 'play' ? 'home-menu-icon-play' : 'home-menu-icon-statistics',
      compact: false,
      variant: 'secondary',
      onActivate: options.onActivate,
    });
  }

  private async launchDaily(entry: DailyEntry): Promise<void> {
    if (this.launchPending) return;
    this.launchPending = true;
    try {
      const attempt = await this.getDailyService().beginDaily(entry.dateKey, entry.id);
      if (attempt === null || !this.scene.isActive()) {
        this.launchPending = false;
        return;
      }
      this.scene.start('GameScene', createDailyGameSceneData(entry, attempt));
    } catch (error) {
      this.launchPending = false;
      console.error(`[Dungeon Logic] Could not start ${entry.id} from Daily hub.`, error);
    }
  }

  private getAvailableViewport(): AvailableViewport {
    return calculateAvailableViewport(
      this.scale.width,
      this.scale.height,
      readCssSafeAreaInsets(),
    );
  }

  private getScrollMaxY(contentBottom: number): number {
    const availableViewport = this.getAvailableViewport();
    return getMetaScrollMaxY(
      availableViewport.height,
      Math.max(0, contentBottom - availableViewport.y),
    );
  }

  private setupPointerOwnership(): void {
    const handlePointerDown = (pointer: Phaser.Input.Pointer): void => {
      this.pointerGate.notePointerDown(pointer.id);
    };
    this.input.on('pointerdown', handlePointerDown);
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, () => {
      this.input.off('pointerdown', handlePointerDown);
    });
  }

  private setupMetaScroll(): void {
    this.scrollMaxY = this.getScrollMaxY(this.contentBottom);

    const camera = this.cameras.main;
    const handleWheel = (
      _pointer: Phaser.Input.Pointer,
      _gameObjects: readonly Phaser.GameObjects.GameObject[],
      _deltaX: number,
      deltaY: number,
    ): void => {
      camera.setScroll(0, clampMetaScrollY(camera.scrollY + deltaY, this.scrollMaxY));
    };
    const handlePointerDown = (pointer: Phaser.Input.Pointer): void => {
      this.scrollPointerId = pointer.id;
      this.scrollStartPointerY = pointer.y;
      this.scrollStartCameraY = camera.scrollY;
      this.scrollGestureDragged = false;
    };
    const handlePointerMove = (pointer: Phaser.Input.Pointer): void => {
      if (this.scrollPointerId !== pointer.id || !pointer.isDown) return;
      if (!this.scrollGestureDragged) {
        this.scrollGestureDragged = isMetaScrollDrag(this.scrollStartPointerY, pointer.y);
      }
      if (!this.scrollGestureDragged) return;
      camera.setScroll(0, clampMetaScrollY(
        this.scrollStartCameraY - (pointer.y - this.scrollStartPointerY),
        this.scrollMaxY,
      ));
    };
    const handlePointerUp = (pointer: Phaser.Input.Pointer): void => {
      if (this.scrollPointerId !== pointer.id) return;
      if (this.scrollGestureDragged) {
        this.lastDraggedPointerId = pointer.id;
        this.lastDragEndedAtMs = Date.now();
      }
      this.scrollPointerId = null;
      this.scrollGestureDragged = false;
    };

    this.input.on('wheel', handleWheel);
    this.input.on('pointerdown', handlePointerDown);
    this.input.on('pointermove', handlePointerMove);
    this.input.on('pointerup', handlePointerUp);
    this.input.on('pointerupoutside', handlePointerUp);
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, () => {
      this.input.off('wheel', handleWheel);
      this.input.off('pointerdown', handlePointerDown);
      this.input.off('pointermove', handlePointerMove);
      this.input.off('pointerup', handlePointerUp);
      this.input.off('pointerupoutside', handlePointerUp);
    });
  }

  private shouldActivatePointer(pointer: Phaser.Input.Pointer): boolean {
    if (!this.pointerGate.canActivate(pointer.id)) return false;
    if (this.scrollPointerId === pointer.id && this.scrollGestureDragged) return false;
    return !(
      this.lastDraggedPointerId === pointer.id
      && Date.now() - this.lastDragEndedAtMs < 160
    );
  }

  private formatTime(ms: number): string {
    const totalSeconds = Math.max(0, Math.floor(ms / 1000));
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  }

  private formatDate(dateKey: string): string {
    const [year, month, day] = dateKey.split('-');
    return `${day}.${month}.${year}`;
  }

  private getDailyService(): DailyService {
    const service = this.registry.get(DAILY_SERVICE_REGISTRY_KEY) as unknown;
    if (!(service instanceof DailyService)) {
      throw new Error('DailyScene requires DailyService in Phaser registry.');
    }
    return service;
  }

  private getProfileService(): PlayerProfileService {
    const service = this.registry.get(PLAYER_PROFILE_SERVICE_REGISTRY_KEY) as unknown;
    if (!(service instanceof PlayerProfileService)) {
      throw new Error('DailyScene requires PlayerProfileService in Phaser registry.');
    }
    return service;
  }
}
