import { readFileSync } from 'node:fs';

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

const gameSceneSource = readFileSync(new URL('../src/scenes/GameScene.ts', import.meta.url), 'utf8');
const boardViewSource = readFileSync(new URL('../src/board/BoardView.ts', import.meta.url), 'utf8');
const cellViewSource = readFileSync(new URL('../src/board/CellView.ts', import.meta.url), 'utf8');

assert(boardViewSource.includes('setTutorialGuideClue('), 'Tutorial must guide the relevant row/column clue.');
assert(boardViewSource.includes('guideCluePulseTween'), 'Guided clue must pulse.');
assert(boardViewSource.includes("? '#f0d28a'"), 'Guided clue must use tutorial gold.');
assert(gameSceneSource.includes('board?.setTutorialGuideClue(step.guideClue ?? null);'), 'Active onboarding step must drive clue guidance.');

assert(cellViewSource.includes('tutorialHighlight'), 'Tutorial target cells need a dedicated highlight layer.');
assert(cellViewSource.includes('tutorialWallGhost'), 'Tutorial WALL target needs a dedicated ghost.');
assert(cellViewSource.includes('tutorialFloorBadge'), 'Tutorial FLOOR target needs a dedicated smaller badge.');
assert(cellViewSource.includes('0xf0d28a'), 'Tutorial FLOOR target must use gold, not reset red.');
assert(cellViewSource.includes('0x7eb6ff'), 'Tutorial WALL target must use blue guidance.');
assert(!cellViewSource.includes('setTint(0xd54a42)'), 'Tutorial target must not reuse the red placed-FLOOR tint.');

assert(!gameSceneSource.includes('0x8a5155'), 'Tutorial tool guidance must not use the old red/coral fill.');
assert(gameSceneSource.includes('guided: boolean;'), 'Toolbar guidance state must be separate from selected state.');
assert(gameSceneSource.includes('if (visual.guided && !visual.disabled)'), 'Guided tool must render a separate treatment.');
assert(gameSceneSource.includes('lineStyle(3, 0xf0bd63'), 'Guided tool must use a gold outline.');
assert(gameSceneSource.includes('buttonState.active ? 0x40577f : 0x18233a'), 'Selected tool must retain the blue active fill.');
assert(gameSceneSource.includes('visual.guided = guided;'), 'Toolbar must sync tutorial guidance independently from active state.');

console.info('[Dungeon Logic] Tutorial guidance visual sanity passed');
