import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

const root = resolve(fileURLToPath(new URL('..', import.meta.url)));
const homePath = resolve(root, 'src/scenes/HomeScene.ts');
const bootPath = resolve(root, 'src/scenes/BootScene.ts');
const rendererPath = resolve(root, 'src/runtime/HomeHubModeCard.ts');

const home = readFileSync(homePath, 'utf8');
const boot = readFileSync(bootPath, 'utf8');

assert(home.includes("from '../runtime/HomeHubModeCard'"), 'Home must use the new HomeHubModeCard renderer.');
assert(home.includes('UI_ICON_KEYS.lock'), 'Locked Home cards must get a dedicated lock glyph.');
assert(home.includes("'#fff1d2'"), 'Unlocked card titles must use the brighter warm-cream palette.');
assert(home.includes("'#c4d0e5'"), 'Unlocked card subtitles must use the brighter cool palette.');
assert(!home.includes("from '../runtime/HomeModeCard'"), 'Home must stop using the legacy HomeModeCard renderer.');
assert(boot.includes('preloadHomeHubModeCardAssets(this);'), 'BootScene must preload the new Home hub card assets.');
assert(existsSync(rendererPath), 'New HomeHubModeCard renderer must exist.');

const renderer = readFileSync(rendererPath, 'utf8');
for (const asset of [
  'public/assets/ui/home_hub_card_tall_active.webp',
  'public/assets/ui/home_hub_card_tall_locked.webp',
  'public/assets/ui/home_hub_card_wide_active.webp',
  'public/assets/ui/home_hub_card_wide_locked.webp',
]) {
  assert(existsSync(resolve(root, asset)), `New Home hub asset must exist: ${asset}`);
}

assert(renderer.includes("type HomeHubModeCardState = 'normal' | 'hover' | 'pressed' | 'locked'"), 'New renderer must own active/hover/pressed/locked states.');
assert(renderer.includes('ACTIVE_SURFACE_KEYS'), 'New renderer must use dedicated active textures.');
assert(renderer.includes('LOCKED_SURFACE_KEYS'), 'New renderer must use dedicated locked textures.');
assert(!renderer.includes('fillMobileTall'), 'Mobile tall Home cards must not stretch the source texture.');
assert(renderer.includes('const displayWidth = sourceWidth * scale;'), 'Home hub cards must preserve source aspect ratio.');
assert(renderer.includes('const displayHeight = sourceHeight * scale;'), 'Home hub cards must preserve source aspect ratio.');
assert(home.includes("this.textures.get('home-hub-card-tall-active').get()"), 'Home mobile tile height must be derived from the actual tall-card asset aspect ratio.');
assert(home.includes('naturalTileWidth / tallCardAspect'), 'Home mobile tile slot must match the source card aspect ratio instead of flattening it.');
assert(renderer.includes('setInteractive({ useHandCursor: true })'), 'Unlocked Home hub cards must remain interactive.');
assert(renderer.includes('getAudioFeedback'), 'New Home hub cards must keep hover/click audio feedback.');
assert(renderer.includes('isTouchLikePointer(pointer)'), 'New Home hub cards must clear synthetic hover after touch release.');

console.info('[Dungeon Logic] Home hub mode card sanity: PASS');
