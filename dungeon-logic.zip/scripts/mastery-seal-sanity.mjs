import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

const root = resolve(fileURLToPath(new URL('..', import.meta.url)));
const boot = readFileSync(resolve(root, 'src/scenes/BootScene.ts'), 'utf8');
const componentPath = resolve(root, 'src/runtime/MasterySeal.ts');

for (const asset of [
  'public/assets/ui/mastery_seal_stone.webp',
  'public/assets/ui/mastery_seal_steel.webp',
  'public/assets/ui/mastery_seal_gold.webp',
  'public/assets/ui/mastery_seal_master.webp',
]) {
  assert(existsSync(resolve(root, asset)), `Mastery seal asset must exist: ${asset}`);
}

assert(existsSync(componentPath), 'MasterySeal component must exist.');
assert(boot.includes('preloadMasterySealAssets(this);'), 'BootScene must preload Mastery seal assets.');

const component = existsSync(componentPath) ? readFileSync(componentPath, 'utf8') : '';
assert(component.includes("case 'I':") && component.includes("case 'II':"), 'Ranks I-II must map to the stone seal.');
assert(component.includes("case 'III':") && component.includes("case 'IV':"), 'Ranks III-IV must map to the steel seal.');
assert(component.includes("case 'V':") && component.includes("case 'VIII':"), 'Ranks V-VIII must map to the gold seal.');
assert(component.includes("case 'MASTER':"), 'MASTER must map to the master seal.');
assert(component.includes('mastery_seal_stone.webp') || component.includes('mastery-seal-stone'), 'Stone seal must have a dedicated asset key/path.');
assert(component.includes('MASTER'), 'Mastery seal component must render rank plaque text dynamically.');

console.info('[Dungeon Logic] Mastery seal sanity: PASS');
