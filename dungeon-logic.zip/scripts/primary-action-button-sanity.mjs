import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

const root = process.cwd();
const rendererPath = resolve(root, 'src/runtime/PrimaryActionButton.ts');
const boot = readFileSync(resolve(root, 'src/scenes/BootScene.ts'), 'utf8');
const home = readFileSync(resolve(root, 'src/scenes/HomeScene.ts'), 'utf8');
const daily = readFileSync(resolve(root, 'src/scenes/DailyScene.ts'), 'utf8');

const asset = 'public/assets/ui/primary_button_normal.webp';
assert(existsSync(resolve(root, asset)), `Primary CTA asset must exist: ${asset}`);

assert(existsSync(rendererPath), 'Shared PrimaryActionButton renderer must exist.');
const renderer = readFileSync(rendererPath, 'utf8');
assert(renderer.includes("fontFamily: 'monospace'"), 'Primary CTA text must remain code-rendered rather than baked into the texture.');

assert(boot.includes('preloadPrimaryActionButtonAssets(this)'), 'BootScene must preload primary CTA textures.');
assert(home.includes('createPrimaryActionButton(scene, {'), 'Home primary campaign action must use the yellow primary CTA renderer.');
assert(daily.includes('if (options.accentFrame) {') && daily.includes('createPrimaryActionButton(this, {'), 'Daily must use the yellow CTA only for the currently primary action.');
assert(daily.includes('createHomeMenuButton(this, {'), 'Daily secondary action must keep the existing dark menu-button renderer.');

console.info('[Dungeon Logic] Primary action button sanity: shared yellow CTA assets and integration passed');
